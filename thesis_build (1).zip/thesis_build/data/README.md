# data/

Place input files here (not version-controlled). Expected files:

| File | Used by | Format |
|------|---------|--------|
| motif_prior.txt | 01_panda_network.R | TF, target, weight |
| ppi_prior.txt | 01_panda_network.R | protein1, protein2, weight |
| expression.txt | 01, 04 | genes x samples matrix |
| sample_meta.tsv | 04 | sample, group, clonal_fraction |
| cdr_genes.txt | 04 | one gene symbol per line |
| serial_cytogenetics.tsv | 03 | patient, time_years, state |
| cn_events.tsv | 05 | chrom, start, end, type |
| gene_positions.tsv | 05 | gene, chrom, pos |
| signature_matrix.tsv | 05 | genes x samples (z-scored) |
| sample_groups.tsv | 05 | sample, group |
