"""
build.py  -  one-command two-pass build of the thesis chapter.

  Pass 1  build_part1 -> build_part2 -> build_part3   (TOC/LoF use placeholder '00')
          compute_toc_pages.py                         (render PDF, read real pages)
  Pass 2  build_part1 -> build_part2 -> build_part3   (TOC/LoF show real pages)

Output: <repo>/build/thesis.docx (and thesis.pdf).
Requires: python-docx, LibreOffice (soffice), poppler (pdftotext/pdfinfo).
Figure images go in <repo>/figures/, named as referenced in build_part2.py.
"""
import os, sys, subprocess

HERE      = os.path.dirname(os.path.abspath(__file__))
BASE      = os.path.dirname(HERE)
BUILD_DIR = os.path.join(BASE, 'build')
PARTS     = ['build_part1.py', 'build_part2.py', 'build_part3.py']
PY        = sys.executable


def run(script):
    print('  ->', script)
    subprocess.run([PY, os.path.join(HERE, script)], check=True)


def run_parts():
    for s in PARTS:
        run(s)


def main():
    os.makedirs(BUILD_DIR, exist_ok=True)
    for f in ('cite_state.pkl', 'toc_pages.json', 'thesis.docx', 'thesis.pdf', 'part1.docx', 'part2.docx'):
        try: os.remove(os.path.join(BUILD_DIR, f))
        except FileNotFoundError: pass
    print('Pass 1 (placeholder page numbers)...'); run_parts()
    print('Computing page numbers...'); run('compute_toc_pages.py')
    print('Pass 2 (final page numbers)...')
    try: os.remove(os.path.join(BUILD_DIR, 'cite_state.pkl'))
    except FileNotFoundError: pass
    run_parts()
    print('\nDone:', os.path.join(BUILD_DIR, 'thesis.docx'))


if __name__ == '__main__':
    main()
