"""Citation manager: assigns reference numbers in order of first appearance,
shared across the three build scripts via a pickled state file."""
import pickle

_assigned = {}
_order = []

# ---- Full reference database (key -> full citation text) ----
_ref_db = {
 # Classification / spectrum / epidemiology
 "arber2016": "Arber DA, Orazi A, Hasserjian R, et al. The 2016 revision to the World Health Organization classification of myeloid neoplasms and acute leukemia. Blood. 2016;127(20):2391-2405.",
 "khoury2022": "Khoury JD, Solary E, Abla O, et al. The 5th edition of the World Health Organization Classification of Haematolymphoid Tumours: Myeloid and Histiocytic/Dendritic Neoplasms. Leukemia. 2022;36(7):1703-1719.",
 "arber2022icc": "Arber DA, Orazi A, Hasserjian RP, et al. International Consensus Classification of Myeloid Neoplasms and Acute Leukemias: integrating morphologic, clinical, and genomic data. Blood. 2022;140(11):1200-1228.",
 "cazzola2020": "Cazzola M. Myelodysplastic Syndromes. N Engl J Med. 2020;383(14):1358-1374.",
 "cogle2015": "Cogle CR. Incidence and Burden of the Myelodysplastic Syndromes. Curr Hematol Malig Rep. 2015;10(3):272-281.",
 "ma2007": "Ma X, Does M, Raza A, Mayne ST. Myelodysplastic syndromes: incidence and survival in the United States. Cancer. 2007;109(8):1536-1542.",
 # Clonal hematopoiesis / CHIP / CCUS
 "jaiswal2014": "Jaiswal S, Fontanillas P, Flannick J, et al. Age-related clonal hematopoiesis associated with adverse outcomes. N Engl J Med. 2014;371(26):2488-2498.",
 "genovese2014": "Genovese G, K\u00e4hler AK, Handsaker RE, et al. Clonal hematopoiesis and blood-cancer risk inferred from blood DNA sequence. N Engl J Med. 2014;371(26):2477-2487.",
 "steensma2015": "Steensma DP, Bejar R, Jaiswal S, et al. Clonal hematopoiesis of indeterminate potential and its distinction from myelodysplastic syndromes. Blood. 2015;126(1):9-16.",
 "malcovati2017": "Malcovati L, Galli A, Travaglino E, et al. Clinical significance of somatic mutation in unexplained blood cytopenia. Blood. 2017;129(25):3371-3378.",
 # AML
 "dohner2022": "D\u00f6hner H, Wei AH, Appelbaum FR, et al. Diagnosis and management of AML in adults: 2022 recommendations from an international expert panel on behalf of the ELN. Blood. 2022;140(12):1345-1377.",
 # Mutational landscape
 "papaemmanuil2013": "Papaemmanuil E, Gerstung M, Malcovati L, et al. Clinical and biological implications of driver mutations in myelodysplastic syndromes. Blood. 2013;122(22):3616-3627.",
 "haferlach2014": "Haferlach T, Nagata Y, Grossmann V, et al. Landscape of genetic lesions in 944 patients with myelodysplastic syndromes. Leukemia. 2014;28(2):241-247.",
 "bejar2011": "Bejar R, Stevenson K, Abdel-Wahab O, et al. Clinical effect of point mutations in myelodysplastic syndromes. N Engl J Med. 2011;364(26):2496-2506.",
 "malcovati2011sf3b1": "Malcovati L, Papaemmanuil E, Bowen DT, et al. Clinical significance of SF3B1 mutations in myelodysplastic syndromes and myelodysplastic/myeloproliferative neoplasms. Blood. 2011;118(24):6239-6246.",
 "gelsiboyer2009asxl1": "Gelsi-Boyer V, Trouplin V, Adela\u00efde J, et al. Mutations of polycomb-associated gene ASXL1 in myelodysplastic syndromes and chronic myelomonocytic leukaemia. Br J Haematol. 2009;145(6):788-800.",
 "delhommeau2009tet2": "Delhommeau F, Dupont S, Della Valle V, et al. Mutation in TET2 in myeloid cancers. N Engl J Med. 2009;360(22):2289-2301.",
 # Cytogenetics / prognosis
 "haase2007": "Haase D, Germing U, Schanz J, et al. New insights into the prognostic impact of the karyotype in MDS and correlation with subtypes: evidence from a core dataset of 2124 patients. Blood. 2007;110(13):4385-4395.",
 "schanz2012": "Schanz J, T\u00fcchler H, Sol\u00e9 F, et al. New comprehensive cytogenetic scoring system for primary myelodysplastic syndromes and oligoblastic acute myeloid leukemia after MDS derived from an international database merge. J Clin Oncol. 2012;30(8):820-829.",
 "greenberg2012ipssr": "Greenberg PL, Tuechler H, Schanz J, et al. Revised international prognostic scoring system for myelodysplastic syndromes. Blood. 2012;120(12):2454-2465.",
 "bernard2022ipssm": "Bernard E, Tuechler H, Greenberg PL, et al. Molecular International Prognostic Scoring System for Myelodysplastic Syndromes. NEJM Evid. 2022;1(7).",
 # Therapy
 "ades2014": "Ad\u00e8s L, Itzykson R, Fenaux P. Myelodysplastic syndromes. Lancet. 2014;383(9936):2239-2252.",
 "fenaux2009aza": "Fenaux P, Mufti GJ, Hellstrom-Lindberg E, et al. Efficacy of azacitidine compared with that of conventional care regimens in the treatment of higher-risk myelodysplastic syndromes: a randomised, open-label, phase III study. Lancet Oncol. 2009;10(3):223-232.",
 "fenaux2020luspatercept": "Fenaux P, Platzbecker U, Mufti GJ, et al. Luspatercept in Patients with Lower-Risk Myelodysplastic Syndromes. N Engl J Med. 2020;382(2):140-151.",
 "list2006len": "List A, Dewald G, Bennett J, et al. Lenalidomide in the myelodysplastic syndrome with chromosome 5q deletion. N Engl J Med. 2006;355(14):1456-1465.",
 "dewitte2017hsct": "de Witte T, Bowen D, Robin M, et al. Allogeneic hematopoietic stem cell transplantation for MDS and CMML: recommendations from an international expert panel. Blood. 2017;129(13):1753-1762.",
 "dinardo2020venaza": "DiNardo CD, Jonas BA, Pullarkat V, et al. Azacitidine and Venetoclax in Previously Untreated Acute Myeloid Leukemia. N Engl J Med. 2020;383(7):617-629.",
 "stone2017flt3": "Stone RM, Mandrekar SJ, Sanford BL, et al. Midostaurin plus Chemotherapy for Acute Myeloid Leukemia with a FLT3 Mutation. N Engl J Med. 2017;377(5):454-464.",
 "stein2017idh2": "Stein EM, DiNardo CD, Pollyea DA, et al. Enasidenib in mutant IDH2 relapsed or refractory acute myeloid leukemia. Blood. 2017;130(6):722-731.",
 # del(20q) clinical / CDR
 "liu2006del20q": "Liu YC, Ito Y, Hsiao HH, et al. Risk factor analysis in myelodysplastic syndrome patients with del(20q): prognosis revisited. Cancer Genet Cytogenet. 2006;171(1):9-16.",
 "braun2011del20q": "Braun T, de Botton S, Taksin AL, et al. Characteristics and outcome of myelodysplastic syndromes with isolated 20q deletion: a report on 62 cases. Leuk Res. 2011;35(7):863-867.",
 "bacher2014del20q": "Bacher U, Haferlach T, Schnittger S, et al. Investigation of 305 patients with myelodysplastic syndromes and 20q deletion for associated cytogenetic and molecular genetic lesions. Leukemia. 2014;28(4):993-1000.",
 "bench2000cdr": "Bench AJ, Nacheva EP, Hood TL, et al. Chromosome 20 deletions in myeloid malignancies: reduction of the common deleted region, generation of a PAC/BAC contig and identification of candidate genes. Oncogene. 2000;19(34):3902-3913.",
 "wangpw1998": "Wang PW, Iannantuoni K, Davis EM, Espinosa R 3rd, Stoffel M, Le Beau MM. Refinement of the commonly deleted segment in myeloid leukemias with a del(20q). Genes Chromosomes Cancer. 1998;21(2):75-81.",
 "huh2010snp": "Huh J, Tiu RV, Gondek LP, et al. Characterization of chromosome arm 20q abnormalities in myeloid malignancies using genome-wide single nucleotide polymorphism array analysis. Genes Chromosomes Cancer. 2010;49(4):390-399.",
 "bernard2020tp53": "Bernard E, Nannya Y, Hasserjian RP, et al. Implications of TP53 allelic state for genome stability, clinical presentation and outcomes in myelodysplastic syndromes. Nat Med. 2020;26(10):1549-1556.",
 # Germline / BMF / somatic rescue
 "dacosta2020dba": "Da Costa L, Leblanc T, Mohandas N. Diamond-Blackfan anemia. Blood. 2020;136(11):1262-1273.",
 "wlodarski2016gata2": "Wlodarski MW, Hirabayashi S, Pastor V, et al. Prevalence, clinical characteristics, and prognosis of GATA2-related myelodysplastic syndromes in children and adolescents. Blood. 2016;127(11):1387-1397.",
 "polprasert2015ddx41": "Polprasert C, Schulze I, Sekeres MA, et al. Inherited and somatic defects in DDX41 in myeloid neoplasms. Cancer Cell. 2015;27(5):658-670.",
 "tesi2017samd9l": "Tesi B, Davidsson J, Voss M, et al. Gain-of-function SAMD9L mutations cause a syndrome of cytopenia, immunodeficiency, MDS, and neurological symptoms. Blood. 2017;129(16):2266-2279.",
 "revy2019somatic": "Revy P, Kannengiesser C, Fischer A. Somatic genetic rescue in Mendelian haematopoietic diseases. Nat Rev Genet. 2019;20(10):582-598.",
 "kennedy2021eif6": "Kennedy AL, Myers KC, Bowman J, et al. Distinct genetic pathways define pre-malignant versus compensatory clonal hematopoiesis in Shwachman-Diamond syndrome. Nat Commun. 2021;12(1):1334.",
 "tan2021eif6": "Tan S, Kermasson L, Hoslin A, et al. EFL1 mutations impair eIF6 release to cause Shwachman-Diamond syndrome. Blood. 2019;134(3):277-290.",
 "nelson2018sds": "Nelson AS, Myers KC. Diagnosis, Treatment, and Molecular Pathology of Shwachman-Diamond Syndrome. Hematol Oncol Clin North Am. 2018;32(4):687-700.",
 # del(5q) / del(7q) haploinsufficiency
 "ebert2008rps14": "Ebert BL, Pretz J, Bosco J, et al. Identification of RPS14 as a 5q- syndrome gene by RNA interference screen. Nature. 2008;451(7176):335-339.",
 "pellagatti2010": "Pellagatti A, Marafioti T, Paterson JC, et al. Induction of p53 and up-regulation of the p53 pathway in the human 5q- syndrome. Blood. 2010;115(13):2721-2723.",
 "kronke2015": "Kr\u00f6nke J, Fink EC, Hollenbach PW, et al. Lenalidomide induces ubiquitination and degradation of CK1\u03b1 in del(5q) MDS. Nature. 2015;523(7559):183-188.",
 "schneider2014": "Schneider RK, Adem\u00e0 V, Heckl D, et al. Role of casein kinase 1A1 in the biology and targeted therapy of del(5q) MDS. Cancer Cell. 2014;26(4):509-520.",
 "mcnerney2013cux1": "McNerney ME, Brown CD, Wang X, et al. CUX1 is a haploinsufficient tumor suppressor gene on chromosome 7 frequently inactivated in acute myeloid leukemia. Blood. 2013;121(6):975-983.",
 "wong2014cux1": "Wong CC, Martincorena I, Rust AG, et al. Inactivating CUX1 mutations promote tumorigenesis. Nat Genet. 2014;46(1):33-38.",
 "chen2014mll3": "Chen C, Liu Y, Rappaport AR, et al. MLL3 is a haploinsufficient 7q tumor suppressor in acute myeloid leukemia. Cancer Cell. 2014;25(5):652-665.",
 # CDR candidate genes
 "macgrogan2004": "MacGrogan D, Kalakonda N, Alvarez S, et al. Structural integrity and expression of the L3MBTL gene in normal and malignant hematopoietic cells. Genes Chromosomes Cancer. 2004;41(3):203-213.",
 "trojer2007": "Trojer P, Li G, Sims RJ 3rd, et al. L3MBTL1, a histone-methylation-dependent chromatin lock. Cell. 2007;129(5):915-928.",
 "heinrichs2013": "Heinrichs S, Conover LF, Bueso-Ramos CE, et al. MYBL2 is a sub-haploinsufficient tumor suppressor gene in myeloid malignancy. Elife. 2013;2:e00825.",
 "avruch2012": "Avruch J, Zhou D, Fitamant J, Bardeesy N, Mou F, Barrufet LR. Protein kinases of the Hippo pathway: regulation and substrates. Semin Cell Dev Biol. 2012;23(7):770-784.",
 "bollu2017": "Bollu LR, Mazumdar A, Savage MI, Brown PH. Molecular Pathways: Targeting Protein Tyrosine Phosphatases in Cancer. Clin Cancer Res. 2017;23(9):2136-2142.",
 # Network / bioinformatics
 "glass2013panda": "Glass K, Huttenhower C, Quackenbush J, Yuan GC. Passing messages between biological networks to refine predicted interactions. PLoS One. 2013;8(5):e64832.",
 "sonawane2017netzoo": "Sonawane AR, Platig J, Fagny M, et al. Understanding tissue-specific gene regulation. Cell Rep. 2017;21(4):1077-1088.",
 "garciaalonso2019dorothea": "Garcia-Alonso L, Holland CH, Ibrahim MM, Turei D, Saez-Rodriguez J. Benchmark and integration of resources for the estimation of human transcription factor activities. Genome Res. 2019;29(8):1363-1375.",
 "hwang2019humannet": "Hwang S, Kim CY, Yang S, et al. HumanNet v2: human gene networks for disease research. Nucleic Acids Res. 2019;47(D1):D573-D580.",
 "brin1998pagerank": "Brin S, Page L. The anatomy of a large-scale hypertextual Web search engine. Computer Networks and ISDN Systems. 1998;30(1-7):107-117.",
 "dobin2013star": "Dobin A, Davis CA, Schlesinger F, et al. STAR: ultrafast universal RNA-seq aligner. Bioinformatics. 2013;29(1):15-21.",
 "liao2014featurecounts": "Liao Y, Smyth GK, Shi W. featureCounts: an efficient general purpose program for assigning sequence reads to genomic features. Bioinformatics. 2014;30(7):923-930.",
 "love2014deseq2": "Love MI, Huber W, Anders S. Moderated estimation of fold change and dispersion for RNA-seq data with DESeq2. Genome Biol. 2014;15(12):550.",
 "iscn2020": "McGowan-Jordan J, Hastings RJ, Moore S, editors. ISCN 2020: An International System for Human Cytogenomic Nomenclature. Karger; 2020.",
 "tiu2011snp": "Tiu RV, Gondek LP, O'Keefe CL, et al. Prognostic impact of SNP array karyotyping in myelodysplastic syndromes and related myeloid malignancies. Blood. 2011;117(17):4552-4560.",
 "benjamini1995": "Benjamini Y, Hochberg Y. Controlling the false discovery rate: a practical and powerful approach to multiple testing. J R Stat Soc Series B. 1995;57(1):289-300.",
 "chakravarty2017oncokb": "Chakravarty D, Gao J, Phillips SM, et al. OncoKB: A Precision Oncology Knowledge Base. JCO Precis Oncol. 2017;2017:PO.17.00011.",
 "suehnholz2024oncokb": "Suehnholz SP, Nissan MH, Zhang H, et al. Quantifying the expanding landscape of clinical actionability for patients with cancer. Cancer Discov. 2024;14(1):49-65.",
 "wickham2019": "Wickham H, Averick M, Bryan J, et al. Welcome to the tidyverse. J Open Source Softw. 2019;4(43):1686.",
 # Cell / flow methods
 "notta2011": "Notta F, Doulatov S, Laurenti E, et al. Isolation of single human hematopoietic stem cells capable of long-term multilineage engraftment. Science. 2011;333(6039):218-221.",
 "pang2011": "Pang WW, Price EA, Sahoo D, et al. Human bone marrow hematopoietic stem cells are increased in frequency and myeloid-biased with age. Proc Natl Acad Sci U S A. 2011;108(50):20012-20017.",
 "gundry2016": "Gundry MC, Brunetti L, Lin A, et al. Highly Efficient Genome Editing of Murine and Human Hematopoietic Progenitor Cells by CRISPR/Cas9. Cell Rep. 2016;17(5):1453-1461.",
 "roth2018": "Roth TL, Puig-Saus C, Yu R, et al. Reprogramming human T cell function and specificity with non-viral genome targeting. Nature. 2018;559(7714):405-409.",
 "livak2001": "Livak KJ, Schmittgen TD. Analysis of relative gene expression data using real-time quantitative PCR and the 2(-Delta Delta C(T)) Method. Methods. 2001;25(4):402-408.",
 "schindelin2012": "Schindelin J, Arganda-Carreras I, Frise E, et al. Fiji: an open-source platform for biological-image analysis. Nat Methods. 2012;9(7):676-682.",
 "eaves2015": "Eaves CJ. Hematopoietic stem cells: concepts, definitions, and the new reality. Blood. 2015;125(17):2605-2613.",
 "sutherland1996": "Sutherland DR, Anderson L, Keeney M, Nayar R, Chin-Yee I. The ISHAGE guidelines for CD34+ cell determination by flow cytometry. J Hematother. 1996;5(3):213-226.",
 "miller1999": "Miller JS, McCullar V, Punzel M, Lemischka IR, Moore KA. Single adult human CD34(+)/Lin-/CD38(-) progenitors give rise to natural killer cells, B-lineage cells, dendritic cells, and myeloid cells. Blood. 1999;93(1):96-106.",
 "civin1984cd34": "Civin CI, Strauss LC, Brovall C, Fackler MJ, Schwartz JF, Shaper JH. Antigenic analysis of hematopoiesis. III. A hematopoietic progenitor cell surface antigen defined by a monoclonal antibody raised against KG-1a cells. J Immunol. 1984;133(1):157-165.",
 "solovjov2005cd11b": "Solovjov DA, Pluskota E, Plow EF. Distinct roles for the alpha and beta subunits in the functions of integrin alphaMbeta2. J Biol Chem. 2005;280(2):1336-1345.",
 # PHF20 / MOF / H4K16 / HDAC
 "smith2005mof": "Smith ER, Cayrou C, Huang R, Lane WS, C\u00f4t\u00e9 J, Lucchesi JC. A human protein complex homologous to the Drosophila MSL complex is responsible for the majority of histone H4 acetylation at lysine 16. Mol Cell Biol. 2005;25(21):9175-9188.",
 "cai2010mof": "Cai Y, Jin J, Swanson SK, et al. Subunit composition and substrate specificity of a MOF-containing histone acetyltransferase distinct from the male-specific lethal (MSL) complex. J Biol Chem. 2010;285(7):4268-4272.",
 "sheikh2016mof": "Sheikh BN, Bechtel-Walz W, Lucci J, et al. MOF maintains transcriptional programs regulating cellular stress response. Oncogene. 2016;35(21):2698-2710.",
 "su2016mof": "Su J, Wang F, Cai Y, Jin J. The Functional Analysis of Histone Acetyltransferase MOF in Tumorigenesis. Int J Mol Sci. 2016;17(1):99.",
 "cui2012phf20": "Cui G, Park S, Badeaux AI, et al. PHF20 is an effector protein of p53 double lysine methylation that stabilizes and activates p53. Nat Struct Mol Biol. 2012;19(9):916-924.",
 "badeaux2012phf20": "Badeaux AI, Yang Y, Cardenas K, et al. Loss of the methyl lysine effector protein PHF20 impacts the expression of genes regulated by the lysine acetyltransferase MOF. J Biol Chem. 2012;287(1):429-437.",
 "klein2016phf20": "Klein BJ, Wang X, Cui G, et al. PHF20 readers link methylation of histone H3K4 and p53 with H4K16 acetylation. Cell Rep. 2016;17(4):1158-1170.",
 "taunton1996hdac": "Taunton J, Hassig CA, Schreiber SL. A mammalian histone deacetylase related to the yeast transcriptional regulator Rpd3p. Science. 1996;272(5260):408-411.",
 "wang2018hdac2": "Wang Y, Tian Y, Morley MP, et al. HDAC2 selectively suppresses HDAC1-induced FOXO3a apoptotic activity in non-small cell lung cancer. J Cell Physiol. 2018;233(1):568-578.",
 "halsall2015": "Halsall JA, Turan N, Wiersma M, Turner BM. Cells adapt to the epigenomic disruption caused by histone deacetylase inhibitors through a coordinated, chromatin-mediated transcriptional response. Epigenetics Chromatin. 2015;8:29.",
 "jiang2014phf20": "Jiang X, Brahmbhatt H, Mirre H, Yang H, Pestell RG. PHF20 in oncogenic protein modification and tumorigenesis. Trends Endocrinol Metab. 2014;25(4):165-167.",
 "park2018phf20hcc": "Park S, Kim D, Dan HC, et al. Identification of PHF20 as a novel regulator of p53 protein levels with implications in hepatocellular carcinoma. Cancer Lett. 2018;425:175-184.",
 "park2017phf20nsclc": "Park S, Park JA, Yoo H, Park HB, Lee Y. PHF20 modulates p53 stability in non-small cell lung cancer. Sci Rep. 2017;7(1):11077.",
 "zhao2021phf20": "Zhao S, Yue Y, Li Y, Li H. PHF20 readers: from chromatin biology to therapeutic opportunities. Cell Mol Life Sci. 2021;78(13):5333-5346.",
 "shogrenknaak2006": "Shogren-Knaak M, Ishii H, Sun JM, Pazin MJ, Davie JR, Peterson CL. Histone H4-K16 acetylation controls chromatin structure and protein interactions. Science. 2006;311(5762):844-847.",
 "robinson2008": "Robinson PJ, An W, Routh A, et al. 30 nm chromatin fibre decompaction requires both H4-K16 acetylation and linker histone eviction. J Mol Biol. 2008;381(4):816-825.",
 "valerio2017mof": "Valerio DG, Xu H, Eisold ME, Woolthuis CM, Pandita TK, Armstrong SA. Histone acetyltransferase activity of MOF is required for adult but not early fetal hematopoiesis in mice. Blood. 2017;129(1):48-59.",
 # Differentiation therapy / HDACi
 "dethe2018": "de Th\u00e9 H. Differentiation therapy revisited. Nat Rev Cancer. 2018;18(2):117-127.",
 "nebbioso2005": "Nebbioso A, Clarke N, Voltz E, et al. Tumor-selective action of HDAC inhibitors involves TRAIL induction in acute myeloid leukemia cells. Nat Med. 2005;11(1):77-84.",
 "garciamanero2008vorinostat": "Garcia-Manero G, Yang H, Bueso-Ramos C, et al. Phase 1 study of the histone deacetylase inhibitor vorinostat in patients with advanced leukemias and myelodysplastic syndromes. Blood. 2008;111(3):1060-1066.",
 "gojo2007entinostat": "Gojo I, Jiemjit A, Trepel JB, et al. Phase 1 and pharmacologic study of MS-275, a histone deacetylase inhibitor, in adults with refractory and relapsed acute leukemias. Blood. 2007;109(7):2781-2790.",
 "prebet2014e1905": "Prebet T, Sun Z, Figueroa ME, et al. Prolonged administration of azacitidine with or without entinostat for myelodysplastic syndrome and acute myeloid leukemia with myelodysplasia-related changes: results of the US Leukemia Intergroup trial E1905. J Clin Oncol. 2014;32(12):1242-1248.",
 "bewersdorf2019": "Bewersdorf JP, Shallis R, Stahl M, Zeidan AM. Epigenetic therapy combinations in acute myeloid leukemia and myelodysplastic syndromes: what are the options? Ther Adv Hematol. 2019;10:2040620718816698.",
}

def C(*keys):
    out = []
    for k in keys:
        if k not in _ref_db:
            raise KeyError("Unregistered reference key: " + k)
        if k not in _assigned:
            _order.append(k)
            _assigned[k] = len(_order)
        out.append(_assigned[k])
    return "[" + ", ".join(str(n) for n in out) + "]"

def save_state(path):
    with open(path, "wb") as f:
        pickle.dump({"assigned": _assigned, "order": _order}, f)

def load_state(path):
    global _assigned, _order
    with open(path, "rb") as f:
        st = pickle.load(f)
    _assigned = st["assigned"]; _order = st["order"]

def ordered_refs():
    return [(_assigned[k], _ref_db[k]) for k in _order]
