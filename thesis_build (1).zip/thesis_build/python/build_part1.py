"""
Front matter, Introduction, Materials & Methods

Document-build pipeline (Python). Paths resolve to the repository root so the
package is portable. Figure images are expected in <repo>/figures/ and output
lands in <repo>/build/.
"""
import os
HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(HERE)              # repository root (python/ -> root)
FIG_DIR   = os.path.join(BASE, 'figures')
BUILD_DIR = os.path.join(BASE, 'build')
os.makedirs(BUILD_DIR, exist_ok=True)
os.makedirs(FIG_DIR,  exist_ok=True)

"""FULL Chapter 1 build — Part 1: Title, expanded Introduction, Methods."""
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import citemod as ct

doc = Document()
for section in doc.sections:
    section.top_margin = Inches(1); section.bottom_margin = Inches(1)
    section.left_margin = Inches(1.5); section.right_margin = Inches(1)
    section.page_height = Inches(11); section.page_width = Inches(8.5)

style = doc.styles['Normal']
style.font.name = 'Times New Roman'; style.font.size = Pt(12)
style.paragraph_format.line_spacing = 2.0
style.paragraph_format.space_after = Pt(0)
style.paragraph_format.first_line_indent = Inches(0.5)

for lvl, sz in [(1, 16), (2, 14), (3, 13)]:
    h = doc.styles[f'Heading {lvl}']
    h.font.name = 'Times New Roman'; h.font.size = Pt(sz); h.font.bold = True
    h.font.color.rgb = RGBColor(0, 0, 0)
    h.paragraph_format.line_spacing = 1.5
    h.paragraph_format.space_before = Pt(18); h.paragraph_format.space_after = Pt(6)
    h.paragraph_format.first_line_indent = Inches(0)

def H1(t):
    p = doc.add_heading(t, level=1); p.paragraph_format.first_line_indent = Inches(0); return p
def H2(t):
    p = doc.add_heading(t, level=2); p.paragraph_format.first_line_indent = Inches(0); return p
def H3(t):
    p = doc.add_heading(t, level=3); p.paragraph_format.first_line_indent = Inches(0); return p

# Caption style (used by figure/placeholder captions; collected by the List of Figures field)
from docx.enum.style import WD_STYLE_TYPE
_existing = [s.name for s in doc.styles]
if 'Caption' in _existing:
    cap_style = doc.styles['Caption']
else:
    cap_style = doc.styles.add_style('Caption', WD_STYLE_TYPE.PARAGRAPH)
cap_style.font.name = 'Times New Roman'; cap_style.font.size = Pt(11)
cap_style.font.italic = False; cap_style.font.bold = False
cap_style.font.color.rgb = RGBColor(0, 0, 0)
cap_style.paragraph_format.line_spacing = 1.15
cap_style.paragraph_format.first_line_indent = Inches(0)
cap_style.paragraph_format.space_after = Pt(12)

def P(t):
    p = doc.add_paragraph(t); p.paragraph_format.line_spacing = 2.0; return p
def PB():
    doc.add_page_break()
C = ct.C

# ===================== FRONT MATTER (CWRU ETD order) =====================
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.enum.section import WD_SECTION

TITLE = "Determining the Etiology and Targetability of del(20q) Myeloid Neoplasms"
AUTHOR = "Mark Orland, MD"
DEGREE = "Doctor of Philosophy"
DEPARTMENT = "Department of Molecular Medicine"   # confirm with program
GRAD_DATE = "May 2026"   # CWRU requires Jan/May/Aug; user indicated June -> using May

def cline(text, bold=False, size=12, italic=False, before=0, after=0, caps=False):
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.first_line_indent = Inches(0)
    p.paragraph_format.line_spacing = 1.0
    p.paragraph_format.space_before = Pt(before); p.paragraph_format.space_after = Pt(after)
    r = p.add_run(text.upper() if caps else text)
    r.bold = bold; r.italic = italic; r.font.size = Pt(size); r.font.name = 'Times New Roman'
    return p

def add_field(paragraph, instr, placeholder):
    run = paragraph.add_run()
    b = OxmlElement('w:fldChar'); b.set(qn('w:fldCharType'), 'begin')
    it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = instr
    sep = OxmlElement('w:fldChar'); sep.set(qn('w:fldCharType'), 'separate')
    t = OxmlElement('w:t'); t.text = placeholder
    e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'), 'end')
    for el in (b, it, sep, t, e):
        run._r.append(el)

# ---- Title page (page i; number suppressed) ----
cline(TITLE, bold=True, size=14, before=72, after=24, caps=True)
cline("by", size=12, after=24)
cline(AUTHOR, bold=True, size=12, after=36)
cline("Submitted in partial fulfillment of the requirements", size=12)
cline("for the degree of " + DEGREE, size=12, after=36)
cline(DEPARTMENT, size=12, after=36)
cline("CASE WESTERN RESERVE UNIVERSITY", size=12, after=36)
cline(GRAD_DATE, size=12)
PB()

# ---- Committee Approval Sheet (page ii) ----
cline("CASE WESTERN RESERVE UNIVERSITY", bold=True, size=12, before=36)
cline("SCHOOL OF GRADUATE STUDIES", bold=True, size=12, after=24)
cline("We hereby approve the dissertation of", size=12, after=18)
cline(AUTHOR, bold=True, size=12, after=18)
cline("candidate for the degree of " + DEGREE + ".*", size=12, after=30)
for role, name in [("Committee Chair", "Babal Jha, PhD"),
                   ("Committee Member", "Jaroslaw P. Maciejewski, MD, PhD (Advisor)"),
                   ("Committee Member", "Yogen Saunthararajah, MD"),
                   ("Committee Member", "Daniel McGrail, PhD")]:
    cline(role, size=12, before=6)
    cline(name, bold=True, size=12, after=6)
cline("Date of Defense", size=12, before=18)
cline("[Date of Defense]", bold=True, size=12, after=24)
cline("*We also certify that written approval has been obtained for any "
      "proprietary material contained therein.", italic=True, size=11)
PB()

# ---- Dedication (page iii) ----
ded = doc.add_paragraph(); ded.alignment = WD_ALIGN_PARAGRAPH.CENTER
ded.paragraph_format.first_line_indent = Inches(0)
ded.paragraph_format.space_before = Pt(220); ded.paragraph_format.line_spacing = 1.5
r = ded.add_run("To my wife, whose patience and love steadied every step of this work,\n"
                "and to my son, who gives all of it its meaning.")
r.italic = True; r.font.size = Pt(12); r.font.name = 'Times New Roman'
PB()

# ---- page-number map (filled from rendered PDF on second pass) ----
import json as _json, os as _os
_PAGES = {}
if _os.path.exists(os.path.join(BUILD_DIR,'toc_pages.json')):
    _PAGES = _json.load(open(os.path.join(BUILD_DIR,'toc_pages.json')))
def _gp(key):
    return str(_PAGES.get(key, '00'))

from docx.enum.text import WD_TAB_ALIGNMENT, WD_TAB_LEADER

# ---- Table of Contents (static, computed page numbers) ----
cline("TABLE OF CONTENTS", bold=True, size=12, after=12)
_toc = [
 ("H1","1.1 Introduction"),
 ("H2","1.1.1 The clonal myeloid continuum: from clonal hematopoiesis to acute leukemia"),
 ("H2","1.1.2 The recurrent somatic mutational landscape of myeloid neoplasms"),
 ("H2","1.1.3 Recurrent cytogenetic abnormalities"),
 ("H2","1.1.4 The therapeutic landscape across the myeloid spectrum"),
 ("H2","1.1.5 The del(20q) lesion: clinical features and candidate mechanisms"),
 ("H2","1.1.6 The present study"),
 ("H1","1.2 Materials and Methods"),
 ("H2","1.2.1 Patient cohorts and ethical oversight"),
 ("H2","1.2.2 Cytogenetic analyses and SNP array"),
 ("H2","1.2.3 Clonality-corrected differential expression analysis"),
 ("H2","1.2.4 Gene regulatory network construction and centrality analysis"),
 ("H3","1.2.4.A Rationale for an integrative network approach"),
 ("H3","1.2.4.B PANDA: message passing for data assimilation"),
 ("H3","1.2.4.C Markov chain (MCMC) centrality and PageRank"),
 ("H3","1.2.4.D Multi-feature biological selection"),
 ("H2","1.2.5 Cell line culture"),
 ("H2","1.2.6 Primary CD34+ HSPC isolation and culture"),
 ("H2","1.2.7 siRNA design, transfection, and qPCR knockdown validation"),
 ("H2","1.2.8 Western blot"),
 ("H3","1.2.8.A Cell harvest and protein lysate preparation"),
 ("H3","1.2.8.B SDS-PAGE"),
 ("H3","1.2.8.C Transfer and immunodetection"),
 ("H3","1.2.8.D Buffer recipes"),
 ("H2","1.2.9 Colony-forming unit assays"),
 ("H2","1.2.10 Flow-cytometric immunophenotyping of myeloid differentiation"),
 ("H2","1.2.11 High-throughput drug screening"),
 ("H2","1.2.12 OncoKB druggable pathway analysis"),
 ("H2","1.2.13 Statistical analysis"),
 ("H1","1.3 Results"),
 ("H2","1.3.1 Cohort assembly and the cytogenetic landscape of myeloid neoplasms"),
 ("H2","1.3.2 Clinical and morphologic phenotype of the del(20q) subset"),
 ("H2","1.3.3 Detection, the Common Deleted Region, and candidate genes"),
 ("H2","1.3.4 Clonality-corrected differential expression isolates copy-number-dependent genes"),
 ("H2","1.3.5 del(20q) does not define a transcriptionally distinct subgroup"),
 ("H2","1.3.6 PANDA identifies PHF20 as a central hub and Markov analysis identifies HDAC2"),
 ("H2","1.3.7 PHF20 expression across the hematopoietic hierarchy and its biochemical role"),
 ("H2","1.3.8 siRNA knockdown of PHF20 in cell lines and primary HSPCs"),
 ("H2","1.3.9 PHF20 knockdown expands clonogenic progenitors"),
 ("H2","1.3.10 Increased clonogenicity without maturation predicts a differentiation block"),
 ("H2","1.3.11 PHF20 knockdown reduces H4K16 acetylation (Western blot)"),
 ("H2","1.3.12 PHF20 knockdown impairs myeloid maturation (flow cytometry)"),
 ("H2","1.3.13 High-throughput drug screening reveals preferential del(20q) sensitivity to HDAC inhibition"),
 ("H2","1.3.14 OncoKB druggability analysis nominates HDAC2 as the actionable node"),
 ("H2","1.3.15 Serial cytogenetics and Markov modeling identify isolated del(20q) as a stable, indolent clonal state"),
 ("H1","1.4 Discussion"),
 ("H2","1.4.1 A unified model of del(20q) myeloid neoplasia"),
 ("H2","1.4.2 Biological rationale for the PHF20\u2013HDAC2 axis"),
 ("H2","1.4.3 HDAC inhibition as differentiation therapy"),
 ("H2","1.4.4 del(20q) in the context of other haploinsufficient deletion syndromes"),
 ("H2","1.4.5 Translational and therapeutic implications"),
 ("H2","1.4.6 The BCL-2 and PI3K axes as parallel vulnerabilities"),
 ("H2","1.4.7 Limitations"),
 ("H2","1.4.8 Future directions"),
 ("H2","1.4.9 Conclusion"),
 ("H1","1.5 References"),
]
def toc_entry(level, text):
    p = doc.add_paragraph(); p.paragraph_format.line_spacing = 1.5
    indent = {"H1":0.0, "H2":0.3, "H3":0.6}[level]
    p.paragraph_format.left_indent = Inches(indent + 0.4)
    p.paragraph_format.first_line_indent = Inches(-0.4)
    p.paragraph_format.tab_stops.add_tab_stop(Inches(6.0), WD_TAB_ALIGNMENT.RIGHT, WD_TAB_LEADER.DOTS)
    r = p.add_run(text); r.bold = (level == "H1")
    r.font.name = 'Times New Roman'; r.font.size = Pt(12)
    p.add_run("\t")
    pr = p.add_run(_gp("HEAD::" + text)); pr.font.name = 'Times New Roman'; pr.font.size = Pt(12)
    return p
for lvl, txt in _toc:
    toc_entry(lvl, txt)
PB()

# ---- List of Figures (page v) ----
cline("LIST OF FIGURES", bold=True, size=12, after=12)
from docx.enum.text import WD_TAB_ALIGNMENT, WD_TAB_LEADER

def lof_entry(num, title):
    p = doc.add_paragraph(); p.paragraph_format.first_line_indent = Inches(0)
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.left_indent = Inches(0.5); p.paragraph_format.first_line_indent = Inches(-0.5)
    p.paragraph_format.tab_stops.add_tab_stop(Inches(6.0), WD_TAB_ALIGNMENT.RIGHT, WD_TAB_LEADER.DOTS)
    r = p.add_run("Figure " + num + ".  " + title); r.font.name = 'Times New Roman'; r.font.size = Pt(12)
    p.add_run("\t")
    pr = p.add_run(_gp("FIG::" + num)); pr.font.name = 'Times New Roman'; pr.font.size = Pt(12)
    return p

_lof = [
    ("1", "Cytogenetic landscape of myeloid neoplasms"),
    ("2", "Clinical and morphologic phenotype of the del(20q) subset"),
    ("3", "Detection of del(20q) by karyotype, FISH, and SNP array"),
    ("4", "Exclusion of germline and somatic gene rescue"),
    ("5", "Definition of the Common Deleted Region"),
    ("6", "Haploinsufficiency of retained genes within the deleted region"),
    ("7", "Gene-dose dependence of CDR gene expression"),
    ("8", "Absence of hierarchical clustering by del(20q) status"),
    ("9", "del(20q) cases cluster within the diploid distribution"),
    ("10", "The 719-gene clonality-correlated signature"),
    ("11", "PANDA network methodology"),
    ("12", "PANDA protein-interaction and RNA-seq input heatmaps"),
    ("13", "Multi-feature selection identifies PHF20"),
    ("14", "PHF20 expression across the hematopoietic hierarchy"),
    ("15", "PHF20, the MOF/NSL complex, and H4K16 acetylation"),
    ("16", "PHF20-HDAC2 relationship and signature overlap"),
    ("17", "qPCR validation of PHF20 knockdown"),
    ("18", "PHF20 knockdown expands clonogenic progenitors"),
    ("19", "PHF20 knockdown reduces H4K16 acetylation (Western blot)"),
    ("20", "PHF20 knockdown impairs myeloid maturation (flow cytometry)"),
    ("21", "High-throughput drug screening"),
    ("22", "OncoKB druggability analysis nominates HDAC2"),
    ("23", "Predicted subcellular localization of differentially expressed gene products"),
    ("24", "Clonal-state trajectories across 31 del(20q) patients with serial cytogenetics"),
]
for num, title in _lof:
    lof_entry(num, title)
PB()

# ---- Abstract (<=350 words) ----
cline(TITLE, bold=True, size=12, after=12)
cline("Abstract", bold=True, size=12, after=6)
cline("by", size=12, after=6)
cline(AUTHOR.upper(), bold=True, size=12, after=18)
abs = doc.add_paragraph(); abs.paragraph_format.first_line_indent = Inches(0.5)
abs.paragraph_format.line_spacing = 2.0
abs.add_run(
    "Interstitial deletion of the long arm of chromosome 20, del(20q), is a recurrent, "
    "favorable-risk lesion in myeloid neoplasms that has remained mechanistically obscure "
    "and therapeutically orphaned. Because no recurrent point mutation occurs on the retained "
    "allele, the lesion is presumed to act through haploinsufficiency, yet the causal gene within "
    "the roughly 126-gene Common Deleted Region has not been established. Using a multi-institutional "
    "cohort of 4,751 patients, we define the cytogenetic landscape in which del(20q) occurs, "
    "characterize the predominantly erythroid and megakaryocytic dysplasia of the del(20q) subset, "
    "and delineate the Common Deleted Region by SNP-array breakpoint mapping. We exclude germline and "
    "somatic gene rescue, the mechanism exemplified by EIF6 deletion in Shwachman-Diamond syndrome, by "
    "showing that the del(20q) mutational landscape mirrors that of diploid disease without a recurrent "
    "20q lesion. Clonality-corrected differential expression isolates copy-number-dependent genes, and "
    "an integrative regulatory-network analysis combining the PANDA message-passing algorithm with "
    "Markov-chain centrality nominates a single haploinsufficient driver, PHF20, a scaffold of the "
    "MOF/NSL histone acetyltransferase complex, while independently identifying its opposing eraser, the "
    "histone deacetylase HDAC2, as the dominant regulatory node. Functional knockdown of PHF20 in myeloid "
    "cell lines and primary CD34-positive progenitors increases clonogenic output while impairing terminal "
    "maturation, reducing the mature CD11b-positive fraction relative to the immature CD34-positive fraction, "
    "the signature of a differentiation block, accompanied by reduced histone H4 lysine-16 acetylation. "
    "High-throughput drug screening and OncoKB druggability analysis converge on HDAC2 inhibition as the "
    "actionable vulnerability, with the pan-HDAC inhibitor panobinostat showing preferential activity in "
    "del(20q) cells. These findings establish PHF20 as the del(20q) driver and reframe a previously "
    "untargetable lesion as a candidate for lesion-directed differentiation therapy through inhibition of "
    "the opposing HDAC2 eraser."
)

# ---- Section break: front matter (roman) -> body (arabic) ----
doc.add_section(WD_SECTION.NEW_PAGE)

# ===================== 2.1 INTRODUCTION =====================
H1("1.1 Introduction")

H2("1.1.1 The clonal myeloid continuum: from clonal hematopoiesis to acute leukemia")
P("All blood cells derive from a small pool of self-renewing hematopoietic stem cells (HSCs) that reside in the bone marrow and give rise, through successively lineage-restricted progenitors, to the myeloid and lymphoid arms of hematopoiesis. The myeloid arm proceeds from the common myeloid progenitor through the granulocyte-monocyte progenitor and the megakaryocyte-erythroid progenitor to produce neutrophils, monocytes, eosinophils, basophils, erythrocytes, and platelets. Faithful execution of this hierarchy depends on the ordered acquisition of lineage-specific gene-expression programs, and its dysregulation, through somatic mutation, chromosomal aberration, or epigenetic perturbation, underlies the myeloid neoplasms (MNs) " + C("arber2016", "khoury2022") + ".")
P("Myeloid neoplasms are increasingly understood not as discrete diseases but as points along a continuum of clonal hematopoiesis, in which a somatically mutated HSC clone progressively expands and, in some individuals, acquires the additional genetic and epigenetic lesions required for overt malignancy " + C("jaiswal2014", "genovese2014", "steensma2015") + ". The entities along this continuum are distinguished by the presence or absence of three features: a clonal marker (a somatic mutation or clonal cytogenetic abnormality), peripheral-blood cytopenias, and morphologic dysplasia or excess blasts in the bone marrow.")
P("Clonal hematopoiesis of indeterminate potential (CHIP) is defined by a somatic mutation in a myeloid-associated gene at a variant allele fraction of at least 2% in an individual with normal blood counts and no morphologic evidence of a hematologic neoplasm; it confers a low but measurable annual risk of progression to overt MN and is associated with increased all-cause and cardiovascular mortality " + C("jaiswal2014", "steensma2015") + ". Clonal cytopenia of undetermined significance (CCUS) describes the same clonal marker accompanied by one or more persistent, otherwise-unexplained cytopenias but without sufficient dysplasia or other criteria to diagnose MDS, and it carries a substantially higher progression risk than CHIP, particularly with high-risk mutation patterns such as spliceosome or co-occurring mutations " + C("malcovati2017") + ".")
P("Myelodysplastic syndromes (MDS) are diagnosed when persistent cytopenias are accompanied by morphologic dysplasia in at least 10% of cells in one or more myeloid lineages, and/or an MDS-defining cytogenetic or molecular lesion, with bone-marrow blasts below 20%; contemporary classifications additionally recognize genetically defined subtypes such as MDS with mutated SF3B1 and MDS with isolated del(5q) " + C("arber2016", "khoury2022", "arber2022icc", "cazzola2020") + ". Myeloproliferative neoplasms (MPNs) are by contrast proliferative rather than dysplastic, characterized by effective but excessive production of one or more mature myeloid lineages driven by constitutive signaling mutations (most often JAK2 V617F, CALR, or MPL), with overlap entities (MDS/MPN, such as chronic myelomonocytic leukemia) exhibiting both dysplastic and proliferative features " + C("arber2016") + ". Acute myeloid leukemia (AML) sits at the malignant end of the continuum, defined classically by 20% or more blasts in the blood or marrow or, irrespective of blast count, by the presence of an AML-defining recurrent genetic abnormality such as t(15;17)/PML-RARA, t(8;21)/RUNX1-RUNX1T1, inv(16), or mutated NPM1 " + C("khoury2022", "dohner2022") + ".")
P("The probability of progression along this continuum scales with the number, identity, and clonal burden of acquired lesions: founding mutations in DNMT3A, TET2, or ASXL1 typically initiate clonal expansion, while subsequent acquisition of spliceosome, signaling, or TP53 lesions and adverse cytogenetic abnormalities drives transformation " + C("jaiswal2014", "papaemmanuil2013") + ". This framework, in which MDS and AML emerge from an expanding, mutation-accruing clone rather than arising fully formed, motivates efforts to define the specific molecular lesions that confer clonal advantage, since each such lesion is in principle a point of therapeutic intervention.")

H2("1.1.2 The recurrent somatic mutational landscape of myeloid neoplasms")
P("Large sequencing studies have defined a recurrent mutational landscape in MN that falls into a small number of functional categories " + C("papaemmanuil2013", "haferlach2014", "bejar2011") + ". The most frequently mutated genes are the DNA-methylation regulators DNMT3A, TET2, and IDH1/IDH2; the chromatin and Polycomb regulators ASXL1 and EZH2; the messenger-RNA splicing factors SF3B1, SRSF2, U2AF1, and ZRSR2; the transcription factors RUNX1 and GATA2; the signaling molecules JAK2, FLT3, NRAS/KRAS, and CBL; the cohesin complex, notably STAG2; and the guardian of the genome, TP53 " + C("papaemmanuil2013", "bejar2011") + ". Individual mutations carry distinct phenotypic and prognostic associations. SF3B1 mutations are tightly linked to ring sideroblasts and a comparatively favorable course " + C("malcovati2011sf3b1") + "; ASXL1 mutations, which disrupt Polycomb-mediated gene repression, recur across the MN spectrum and portend adverse outcomes " + C("gelsiboyer2009asxl1") + "; and TET2 and DNMT3A mutations are among the most common initiating events in age-related clonal hematopoiesis " + C("delhommeau2009tet2", "jaiswal2014") + ". Of particular relevance to the present work, ASXL1 is located on the proximal long arm of chromosome 20, at band 20q11.21, immediately adjacent to the cytogenetic lesion that is the subject of this chapter " + C("gelsiboyer2009asxl1") + ".")

H2("1.1.3 Recurrent cytogenetic abnormalities")
P("Beyond point mutations, recurrent chromosomal abnormalities are present in roughly half of MDS cases and constitute one of the strongest prognostic axes, forming the cytogenetic backbone of the Revised International Prognostic Scoring System and its molecular successor " + C("haase2007", "schanz2012", "greenberg2012ipssr", "bernard2022ipssm") + ". The most common recurrent abnormalities are unbalanced losses and gains rather than balanced translocations. Deletion of the long arm of chromosome 5, del(5q), or monosomy 5 is the single most frequent, followed by loss of chromosome 7 or its long arm (\u22127/del(7q)), trisomy 8 (+8), deletion of the long arm of chromosome 20 (del(20q)), and loss of the Y chromosome (\u2212Y) " + C("haase2007", "schanz2012") + ". These lesions differ markedly in prognostic weight: isolated del(5q) and \u2212Y are favorable, +8 is intermediate, and \u22127/del(7q) and complex karyotypes are adverse " + C("greenberg2012ipssr", "schanz2012") + ". Isolated del(20q), the focus of this work, is classified as a good-risk lesion " + C("greenberg2012ipssr") + ". The mechanistic basis of most of these recurrent deletions, namely the identity of the specific haploinsufficient gene or genes whose loss confers clonal advantage, has been defined for only a minority, most completely for del(5q).")

H2("1.1.4 The therapeutic landscape across the myeloid spectrum")
P("The therapeutic options available across the clonal myeloid continuum are strikingly uneven, and the disparity underscores the value of lesion-directed strategies. For CHIP and CCUS there is no approved disease-directed therapy; management is limited to observation, cardiovascular risk reduction, and treatment of any associated cytopenia, although the elevated mortality associated with clonal hematopoiesis has prompted active investigation of interventions targeting the inflammatory and clonal-fitness consequences of these mutations " + C("jaiswal2014", "steensma2015") + ". For MDS, treatment is risk-adapted: lower-risk disease is managed with erythropoiesis-stimulating agents, luspatercept for ring-sideroblast or SF3B1-mutant subtypes, and lenalidomide for del(5q), while higher-risk disease is treated with hypomethylating agents (azacitidine, decitabine) and, in eligible patients, allogeneic hematopoietic stem-cell transplantation, the only curative modality " + C("ades2014", "fenaux2009aza", "fenaux2020luspatercept", "list2006len", "dewitte2017hsct") + ". Critically, with the single exception of lenalidomide for del(5q), no MDS therapy is directed at a specific cytogenetic lesion.")
P("For AML, the therapeutic repertoire has expanded to include intensive induction chemotherapy, the venetoclax-plus-hypomethylating-agent backbone for older or unfit patients, and mutation-targeted agents against FLT3 and IDH1/IDH2, alongside transplantation " + C("dinardo2020venaza", "stone2017flt3", "stein2017idh2", "dohner2022") + ". Despite these advances, AML remains frequently fatal, with five-year survival below 30% overall and far lower in older and adverse-risk patients " + C("dohner2022") + ". The steep survival gradient from indolent clonal hematopoiesis to lethal acute leukemia provides the central clinical rationale for this work: identifying the molecular driver of a recurrent but currently untargetable lesion such as del(20q) offers the possibility of lesion-directed intervention earlier in the continuum, when disease is more indolent and more tractable.")

H2("1.1.5 The del(20q) lesion: clinical features and candidate mechanisms")
P("Isolated del(20q) is a recurrent, favorable-risk lesion found across the MN spectrum and at highest frequency in MPN, yet it remains mechanistically obscure and therapeutically orphaned " + C("liu2006del20q", "braun2011del20q", "bacher2014del20q") + ". Two features frame the search for its driver. First, the deletion boundaries are highly conserved, defining a Common Deleted Region (CDR) on proximal-to-mid 20q that contains roughly 126 protein-coding genes " + C("bench2000cdr", "wangpw1998", "huh2010snp") + ". Several genes within this region, including L3MBTL1 and MYBL2, have over the years been proposed as candidate contributors to the del(20q) phenotype, but none has been established as the operative driver " + C("macgrogan2004", "heinrichs2013") + ". Second, unlike classical two-hit tumor suppressors such as TP53, no recurrent inactivating point mutation has been identified in the retained 20q allele, indicating that the lesion acts through gene dosage rather than through biallelic inactivation " + C("bernard2020tp53") + ".")
P("An instructive context for interpreting recurrent deletions is provided by the inherited bone-marrow-failure and myeloid-predisposition syndromes, in which a germline lesion creates a maladapted hematopoietic state that selects for compensatory somatic events. Such syndromes include Fanconi anemia, dyskeratosis congenita, Diamond-Blackfan anemia, and Shwachman-Diamond syndrome, as well as the germline predisposition disorders caused by mutations in DDX41, GATA2, RUNX1, SAMD9/SAMD9L, ANKRD26, and ETV6 " + C("dacosta2020dba", "wlodarski2016gata2", "polprasert2015ddx41", "tesi2017samd9l") + ". In several of these, the marrow acquires clonal somatic events that mitigate the germline defect, a phenomenon termed somatic genetic rescue " + C("revy2019somatic") + ". The canonical example involving chromosome 20q is Shwachman-Diamond syndrome, caused by biallelic loss of SBDS on chromosome 7, in which the SBDS protein, together with the GTPase EFL1, is required to release the anti-association factor EIF6, encoded on 20q, from the maturing 60S ribosomal subunit. In SBDS-deficient marrow, acquired del(20q) and isochromosome 20q lesions that reduce EIF6 gene dosage partially restore ribosome maturation, and this del(20q) is consequently a recurrent, relatively benign clonal finding associated with a lower risk of leukemic progression, an unambiguous instance of somatic gene rescue mediated by 20q deletion " + C("kennedy2021eif6", "tan2021eif6", "nelson2018sds") + ".")
P("These observations raise the central mechanistic question of this chapter: by what route does del(20q) confer clonal advantage in de novo myeloid neoplasia? Four mutually distinguishable mechanisms can be enumerated. First, germline somatic rescue, in which the deletion recurrently removes a pathogenic germline allele residing on 20q, as EIF6 deletion rescues SBDS deficiency; this predicts a discoverable recurrent germline 20q variant on the retained allele. Second, somatic rescue, in which the deletion removes an acquired somatic lesion on 20q, predicting a recurrent somatic 20q event that the deletion eliminates. Third, allelic imbalance, in which loss of one 20q allele skews the balance of expressed alleles or unmasks a functional polymorphism, altering the dosage of an allele-specific transcript. Fourth, haploinsufficiency of a tumor suppressor, in which the deletion reduces the dosage of one or more 20q tumor-suppressor genes below the threshold required for normal function, conferring clonal advantage without any second hit, the mechanism established for RPS14 and CSNK1A1 in del(5q) and for CUX1 and MLL3 in del(7q) " + C("ebert2008rps14", "kronke2015", "mcnerney2013cux1", "chen2014mll3") + ". Distinguishing among these possibilities is a prerequisite to identifying the driver and is the first objective of the work described below.")

H2("1.1.6 The present study")
P("To resolve the mechanism of del(20q) and to identify its driver, we assembled a multi-institutional cohort of 4,751 myeloid-neoplasm patients and characterized the clinical, morphologic, cytogenetic, and molecular features of the recurrent deletions, including del(5q), \u22127/del(7q), and del(20q). We first defined the phenotype of the del(20q) subset, including its disease distribution (highest in MPN), its predominantly erythroid and megakaryocytic dysplasia (emperipolesis is a recognized morphologic feature of del(20q) but was not specifically scored in this study), and its frequent occurrence as an isolated lesion, and we delineated the conserved CDR by SNP-array breakpoint mapping. We then tested the four candidate mechanisms directly. Sequencing of the del(20q) cohort revealed no recurrent pathogenic germline variant on 20q and no recurrent somatic 20q lesion, excluding both germline and somatic gene rescue; moreover, the genome-wide somatic mutational landscape of del(20q) cases broadly mirrored that of cytogenetically diploid controls, with no del(20q)-specific recurrent mutation and with the common myeloid mutations TET2, ASXL1, and SF3B1 in fact occurring less frequently in del(20q) " + C("revy2019somatic") + ". These findings excluded gene rescue and focused attention on allelic imbalance and, in particular, on haploinsufficiency of a 20q tumor suppressor as the operative mechanism.")
P("To identify which of the approximately 126 CDR genes mediates the haploinsufficient phenotype, we performed clonality-corrected differential expression analysis to isolate the genes whose expression scales with copy-number loss, followed by an unbiased, integrative regulatory-network analysis. We constructed a gene regulatory network with the PANDA message-passing algorithm, which assimilates transcription-factor binding motifs, protein-protein interactions, and gene co-expression, and we analyzed the network by two complementary centrality criteria: structural hub identification within the integrated network, and Markov chain (random-walk) centrality to locate the nodes through which regulatory flow concentrates. Superimposing an eight-feature biological-prioritization grid on the network output then nominated a single CDR gene as the haploinsufficient driver, PHF20, while the Markov analysis independently nominated its functional antagonist, the histone deacetylase HDAC2, as the dominant regulatory node and candidate therapeutic target. The functional characterization of PHF20 loss, its biochemical mechanism through the MOF/NSL histone-acetyltransferase complex, the resulting myeloid differentiation block, and the consequent therapeutic vulnerability to HDAC inhibition form the substance of this chapter and are developed in the sections that follow.")

# ===================== 2.2 METHODS =====================
PB()
H1("1.2 Materials and Methods")

H2("1.2.1 Patient cohorts and ethical oversight")
P("All work involving human samples was conducted under institutional review board approval (protocol 5024) at the Cleveland Clinic Foundation under protocols permitting the collection, storage, and molecular analysis of bone marrow and peripheral blood from patients with hematologic malignancies and from healthy donors. Written informed consent was obtained from all participants in accordance with the Declaration of Helsinki. The combined multi-institutional cohort comprised 4,751 MN patients pooled from five sources: the Cleveland Clinic Foundation (n = 1,248), the Munich Leukemia Laboratory (MLL; n = 1,923), The Cancer Genome Atlas (n = 200), the BEAT AML Master Trial (n = 482), and aggregated open-source data (n = 898). Cytogenetic data were available in 2,022 patients, and SNP-array data for delineation of CDRs were available in 1,247 patients with copy-number abnormalities in 5q, 7q, 8, or 20q. The MDS bulk transcriptomic cohort (n = 772) used for network analysis was contributed by MLL under a separate ethics approval, comprising patients with morphologically and cytogenetically confirmed MDS spanning all 2016 WHO subtypes " + C("arber2016") + "; the del(20q) subgroup was defined by conventional G-banded karyotype and confirmed by interphase fluorescence in situ hybridization (FISH). The institutional Cleveland Clinic validation cohort of del(20q) patients (n = 62) used for SNP-array delineation of the CDR was characterized on the Affymetrix CytoScan HD platform and supplemented by next-generation sequencing of a myeloid gene panel " + C("haferlach2014") + ". Healthy bone marrow donors for CD34-positive cell isolation were 18\u201365 years of age, with normal complete blood counts and no personal or family history of hematologic disorders.")

H2("1.2.2 Cytogenetic analyses and SNP array")
P("Cytogenetic abnormalities were detected using three complementary platforms. Metaphase cytogenetics was performed on colchicine-arrested cells with G-banded karyotyping according to ISCN 2020 conventions " + C("iscn2020") + ". Interphase FISH used a dual-color probe set targeting 20q12 (orange) and a centromeric chromosome 8 sequence (green) as the diploid reference, with at least 200 cells scored per sample. SNP-array analysis was performed on the Affymetrix CytoScan HD platform, enabling detection of copy-number alterations as small as 25 kb and of copy-neutral loss of heterozygosity (CN-LOH); analysis used Chromosome Analysis Suite v4.0 with thresholds of 1 Mb for copy-number gains and losses and 5 Mb for CN-LOH " + C("tiu2011snp") + ". From the SNP-array data, copy-number log2 ratio and B-allele-frequency plots confirmed the 20q deletions and delineated the precise boundaries of each patient's deleted segment. The minimal region shared across patients defined the Common Deleted Region, and the protein-coding genes contained within it (126 genes) were enumerated by mapping this interval onto RefSeq gene annotations in the UCSC Genome Browser (GRCh38).")

H2("1.2.3 Clonality-corrected differential expression analysis")
P("For the clonality-corrected analysis we used gene-level expression from the contributing MN cohorts. Where processed expression matrices were provided (MLL, TCGA), these were used directly; where raw sequencing reads were processed in house, reads were aligned to GRCh38 and quantified to gene-level counts using STAR and featureCounts " + C("dobin2013star", "liao2014featurecounts") + ". Differential expression used DESeq2 " + C("love2014deseq2") + " with a clonality-corrected linear regression model: for each gene and each del(20q) patient, expression was modeled as a linear function of the patient-specific clonal fraction of the del(20q) lesion (estimated from SNP array), and the regression-derived expression at theoretical 100% clonal fraction was used as the corrected expression value, emulating a pure gene-dosage effect that controls for the proportion of non-deleted cells. Differential expression was then assessed between corrected del(20q) values and diploid controls at FDR < 0.05, with a secondary filter of R\u00b2 > 0.1 for the clonal-fraction regression retaining only genes whose expression demonstrably correlated with copy-number loss. Genes passing both filters are termed CN-dependent or clonality-correlated.")

H2("1.2.4 Gene regulatory network construction and centrality analysis")
H3("1.2.4.A Rationale for an integrative network approach")
P("Map position alone does not tell us which of the 126 CDR genes is the driver, and no single data type settles it: transcription-factor binding motifs predict potential regulation but are noisy and ignore cellular context; protein\u2013protein interactions (PPI) capture physical cooperativity but not directionality; and mRNA co-expression captures coordinated activity but cannot distinguish direct regulation from shared upstream control. We therefore adopted a two-stage strategy. First, the Passing Attributes between Networks for Data Assimilation (PANDA) message-passing algorithm " + C("glass2013panda") + " was used to assimilate all three data types into a single, denoised, weighted gene regulatory network in which an edge is reinforced only where independent evidence types agree. Second, the converged network was analyzed as a Markov chain to rank genes by their global regulatory influence, the stationary distribution of a random walk, equivalently the PageRank. The two steps measure different things. PANDA scores a gene by how centrally it sits in the protein-interaction-reinforced network, which favors scaffolds and complex members; the Markov step scores a gene by how much regulatory flow passes through it, which favors transcription factors and enzymes. The two scores need not agree, and in this network they pick out different genes (Results).")
H3("1.2.4.B PANDA: message passing for data assimilation")
P("PANDA " + C("glass2013panda") + ", implemented in netZooR " + C("sonawane2017netzoo") + ", takes three inputs: an initial TF\u00d7gene regulatory prior W\u2070 derived from TF\u2013target binding motifs (DoRothEA, confidence A\u2013C " + C("garciaalonso2019dorothea") + "); a TF\u00d7TF protein cooperativity matrix P from PPI data (HumanNet v3 " + C("hwang2019humannet") + "); and a gene\u00d7gene co-expression matrix C computed from the MLL cohort (n = 772) on quantile-normalized log2 expression. The algorithm refines the regulatory network W by iteratively passing two complementary messages. The Responsibility R_ij compares the protein-interaction partners of TF i (row i of P) with the set of TFs that currently regulate gene j (column j of W), using a continuous Tanimoto similarity T_Z; a high R_ij means that TF i's physical-interaction neighborhood is consistent with the regulators already assigned to gene j, providing proteomic support for the edge. The Availability A_ij compares the current target profile of TF i (row i of W) with the co-expression neighborhood of gene j (column j of C); a high A_ij means that the targets of TF i co-express with gene j, providing transcriptomic support. The two messages are averaged, W\u0303_ij = 0.5\u00b7A_ij + 0.5\u00b7R_ij, and the network is updated under a learning rate \u03b1, W_ij^(t+1) = (1\u2212\u03b1)\u00b7W_ij^(t) + \u03b1\u00b7W\u0303_ij, with P and C updated reciprocally to remain consistent with W. Iteration continues until the network converges (change in edge weights below a Hamming-distance threshold). PANDA was run with \u03b1 = 0.1 and convergence at Hamming distance < 0.001. The output is a fully connected, weighted, directed bipartite TF\u2192gene network whose edge weights are z-scores reflecting the integrated, mutually reinforcing evidence from all three data types. A consequence of incorporating the PPI prior is that genes encoding densely interacting, complex-forming proteins, such as scaffold subunits of chromatin-modifying complexes, accumulate high integrated connectivity and emerge as structural hubs even when their direct TF\u2192target out-degree is modest.")
H3("1.2.4.C Markov chain (MCMC) centrality and PageRank")
P("To rank genes by global regulatory influence within the converged PANDA network, the network was modeled as a Markov chain and the stationary distribution of a random walk was estimated. The premise is dynamical: if a perturbation propagates through the regulatory network as a random walk, the genes at which the walk spends the greatest fraction of its time, the nodes of highest stationary probability, are those through which regulatory flow concentrates and whose perturbation has the broadest downstream consequence. The weighted network was first converted to a row-stochastic transition matrix M by normalizing each node's outgoing edge weights to sum to one, so that M_ab is the probability that a walker at gene a steps to gene b. A damping factor d = 0.85 was applied: at each step the walker follows an outgoing edge with probability d and, with probability 1 \u2212 d, teleports to a uniformly random node, which guarantees ergodicity and a unique stationary distribution \u03c0 satisfying \u03c0 = d\u00b7M\u1d40\u03c0 + (1\u2212d)/N\u00b71. The stationary distribution was estimated by Markov chain Monte Carlo (MCMC), simulating random walks across the network until the empirical visit-frequency distribution converged (1,000 iterations; convergence monitored by the Gelman\u2013Rubin statistic and stabilization of node rankings). The resulting per-gene stationary probability is the PageRank centrality " + C("brin1998pagerank") + "; genes were ranked by this value. Because PageRank rewards transcriptional out-degree and flow centrality, it preferentially elevates broadly-acting transcription factors and enzymes, while genes that act through protein-complex scaffolding rather than through high transcriptional out-degree receive lower stationary probability, a property that proves useful here rather than limiting (Results). For completeness, total weighted degree and betweenness centrality were also computed, and a composite importance score was recorded as the geometric mean of percentile-rank-normalized centralities.")
H3("1.2.4.D Multi-feature biological selection")
P("An eight-feature curated biological selection grid was superimposed on the network output. For each candidate CDR gene we annotated, from primary literature and database queries: (i) haploinsufficiency status (ClinGen, DECIPHER); (ii) demonstrated gene-dose effect; (iii) master-regulator or hub status in the PANDA network; (iv) detectable expression in normal HSCs (Human Protein Atlas single-cell data); (v) prior designation as a known tumor suppressor; (vi) documented decreased expression in MN; (vii) implication in other malignancies; and (viii) embryonic lethality of homozygous murine knockouts. Candidates satisfying all eight criteria were prioritized for functional investigation.")

H2("1.2.5 Cell line culture")
P("K562 (ATCC CCL-243), THP-1 (ATCC TIB-202), and TF1 (ATCC CRL-2003) were maintained in RPMI-1640 with 10% heat-inactivated FBS, 100 U/mL penicillin/streptomycin, and 2 mM L-glutamine; TF1 medium additionally contained 2 ng/mL recombinant human GM-CSF. All lines were maintained at 37 \u00b0C in 5% CO2, subcultured every 48\u201372 hours, authenticated by STR profiling within six months of use, and tested negative for Mycoplasma.")

H2("1.2.6 Primary CD34+ HSPC isolation and culture")
P("Healthy bone marrow aspirates were processed within four hours. Mononuclear cells were isolated by Ficoll-Paque PLUS density gradient centrifugation after dilution in PBS/2% FBS/2 mM EDTA. CD34-positive cells were enriched by immunomagnetic positive selection (CD34 MicroBead Kit UltraPure, Miltenyi) on the autoMACS Pro Separator. Post-selection purity (anti-CD34-APC, clone 581) and viability (7-AAD) were assessed by flow cytometry; only preparations with \u2265 90% purity and \u2265 80% viability were used. Cells were cultured in StemSpan SFEM II with the CC100 cytokine cocktail (SCF, FLT3L, IL-3, IL-6) " + C("notta2011", "pang2011") + ".")

H2("1.2.7 siRNA design, transfection, and qPCR knockdown validation")
P("PHF20 knockdown used a pool of three Silencer Select siRNAs (Thermo Fisher) targeting distinct exonic regions of NM_016436.5, with a non-targeting control siRNA (NTC). The siRNA concentrations of 10 and 25 nM were established in preliminary dose-titration experiments as the range giving maximal transcript knockdown with minimal nonspecific toxicity. Both cell lines and primary CD34+ HSPCs were transfected with Lipofectamine RNAiMAX by reverse transfection in antibiotic-free medium (1.5 \u00d7 10^5 cells per 24-well for cell lines; 2 \u00d7 10^5 cells for primary CD34+ HSPCs) at 10 or 25 nM siRNA " + C("gundry2016", "roth2018") + ". Knockdown was maximal between 48 and 72 h, and all functional assays were therefore initiated at 72 h after transfection to capture the peak effect of the knockdown.")
P("Transcript-level knockdown was confirmed by RT-qPCR on the QuantStudio 6 Flex using TaqMan Gene Expression Master Mix and assays for PHF20 (Hs00226457_m1) and ACTB (Hs01060665_g1). Total RNA was isolated with the RNeasy Mini Kit with on-column DNase I digestion; cDNA was synthesized from 500 ng RNA. Cycling was 50 \u00b0C \u00d7 2 min, 95 \u00b0C \u00d7 10 min, then 40 cycles of 95 \u00b0C \u00d7 15 s and 60 \u00b0C \u00d7 1 min, in technical triplicate. Relative expression used the 2^\u2212\u0394\u0394Ct method " + C("livak2001") + ": \u0394Ct_sample = Ct(PHF20) \u2212 Ct(ACTB); \u0394\u0394Ct = \u0394Ct_sample \u2212 \u0394Ct_control; Relative Expression = 2^\u2212\u0394\u0394Ct. No-template and no-RT controls were included on every plate.")

H2("1.2.8 Western blot")
P("Knockdown of PHF20 at the protein level and quantification of H4K16 acetylation were assessed by Western blot following the standard protocol of our laboratory, detailed below.")
H3("1.2.8.A Cell harvest and protein lysate preparation")
P("(1) Remove culture medium; wash cells in ice-cold PBS. (2) For suspension cells, pellet at 300 \u00d7 g for 5 min at 4 \u00b0C and wash once in ice-cold PBS with 1\u00d7 protease and phosphatase inhibitors added fresh. (3) Pellet at 16,000 \u00d7 g for 45 s at 4 \u00b0C. (4) Resuspend in 1\u00d7 RIPA lysis buffer (40\u201350 \u00b5L per 5 \u00d7 10^6 cells); incubate on ice 30 min with brief vortexing every 10 min. (5) Centrifuge at 9,300 \u00d7 g for 15 min at 4 \u00b0C; collect clarified supernatant into pre-chilled tubes; aliquot and store at \u221280 \u00b0C. Protein concentration was measured by BCA assay at 562 nm.")
H3("1.2.8.B SDS-PAGE")
P("Samples (100\u2013200 \u00b5g total protein per lane) were combined 1:1 with 2\u00d7 Laemmli sample buffer (freshly prepared with \u03b2-mercaptoethanol), wrapped in Parafilm, and boiled for 10 min. Samples were loaded on 4\u201320% gradient SDS-PAGE precast gels (Bio-Rad) alongside Precision Plus Protein WesternC Standards and run at 150 V for 1 h in 1\u00d7 SDS-PAGE running buffer. A 4\u201320% gradient was chosen so that a single gel would resolve both the small histone mark H4K16ac (histone H4, approximately 11 kDa) and the much larger PHF20 protein (approximately 100 kDa).")
H3("1.2.8.C Transfer and immunodetection")
P("Transfer buffer (700 mL water + 100 mL of 10\u00d7 Towbin transfer buffer + 200 mL methanol) was pre-chilled to 4 \u00b0C. PVDF membranes were activated in 100% methanol for 1 min and equilibrated in transfer buffer. Sandwiches were assembled black cassette / sponge / 2 Whatman / gel / PVDF / 2 Whatman / sponge / white cassette, with air bubbles eliminated by rolling. Cassettes were inserted with the gel facing the negative electrode and transfer was run at 100 V for 1 h 20 min on ice with stirring. Membranes were blocked in 5% nonfat dry milk in TBST for 30 to 60 min at room temperature, with 5% BSA in TBST used for acetyl-epitope detection. Primary antibodies were incubated overnight at 4 \u00b0C in the cold room on a rocker: anti-PHF20 (CST #3934, 1:2000), anti-H4K16ac (Abcam ab109463, 1:2000), and anti-\u03b2-actin (Sigma A5316, 1:5000), each diluted per the manufacturer specification. Anti-total-H4 was not used; \u03b2-actin served as the single loading control. After three TBST washes, membranes were incubated with HRP-conjugated secondary antibodies (1 h at room temperature), washed, and developed with SuperSignal West Pico PLUS ECL on the Bio-Rad ChemiDoc MP. Densitometry was performed in Fiji/ImageJ " + C("schindelin2012") + ", with the integrated density of each target band normalized to the \u03b2-actin band on the same membrane and expressed as a fraction of the NTC condition. Three biological replicates were performed per condition.")
H3("1.2.8.D Buffer recipes")
P("1\u00d7 RIPA lysis buffer (1000 \u00b5L): 500 \u00b5L of 2\u00d7 RIPA stock + 100 \u00b5L of 10\u00d7 protease inhibitor + 100 \u00b5L of 10\u00d7 PhosSTOP + 300 \u00b5L water. 2\u00d7 RIPA stock (100 mL): 10 mL of 1 M Tris pH 8.0, 20 mL of 10% NP-40, 0.5 g sodium deoxycholate, 1.72 g NaCl, water to 100 mL. Strong stripping buffer (100 mL): 6.25 mL of 1 M Tris-HCl pH 7.4, 20 mL of 10% SDS, 73.75 mL water; add 100 \u00b5L \u03b2-mercaptoethanol per 15 mL before use. 2\u00d7 Laemmli (10 mL): 1.25 mL of 1 M Tris-HCl pH 6.8, 2.0 mL of 10% SDS, 2.5 mL glycerol, bromophenol blue, 0.5 mL \u03b2-mercaptoethanol, water to 10 mL; prepare fresh. 10\u00d7 TBS (1 L): 300 mL of 5 M NaCl, 100 mL of 1 M Tris-HCl pH 7.5, water to 1 L. 10\u00d7 SDS-PAGE running buffer (1 L): 30.3 g Tris base, 144 g glycine, 10 g SDS, water to 1 L. 10\u00d7 transfer buffer (Towbin, 1 L): 30.3 g Tris base, 144 g glycine, water to 1 L (no SDS).")

H2("1.2.9 Colony-forming unit assays")
P("CFU assays used MethoCult H4434 Classic, containing SCF, GM-CSF, IL-3, IL-6, and erythropoietin, supporting CFU-GM, BFU-E, CFU-E, and CFU-GEMM colonies " + C("eaves2015") + ". For each condition, 2 \u00d7 10^5 CD34+ HSPCs transfected with PHF20 siRNA (10 or 25 nM) or NTC (10 or 25 nM) were harvested at 72 h after transfection, resuspended in 300 \u00b5L of IMDM with 2% FBS, mixed with 3 mL of MethoCult, and dispensed via blunt needle into 35 mm gridded dishes. Colonies were scored on day 14 at 40\u00d7 magnification per STEMCELL Technologies and ISHAGE consensus criteria " + C("sutherland1996", "miller1999") + ". All scoring was performed by the single investigator (M.O.) across three independent biological replicates from distinct donors.")

H2("1.2.10 Flow-cytometric immunophenotyping of myeloid differentiation")
P("To assess the effect of PHF20 knockdown on myeloid maturation, the relative abundance of the immature progenitor compartment (CD34-positive) and the mature myelomonocytic compartment (CD11b-positive) was quantified by multiparameter flow cytometry. Normal bone marrow mononuclear cells were transfected with the PHF20 siRNA pool (25 nM) or the NTC siRNA (25 nM) using Lipofectamine RNAiMAX as in Section 1.2.7, with an untransfected normal bone marrow arm carried in parallel. Immunophenotyping was performed at 3 days after transfection, the window of maximal knockdown, so that the measured shift in the CD34 and CD11b compartments reflects the peak effect of PHF20 loss.")
P("On the day of analysis, cells were harvested, washed twice in FACS buffer (PBS with 2% FBS and 2 mM EDTA), and counted, with cell viability determined by trypan blue exclusion on a Vi-CELL automated cell counter. 1 \u00d7 10^6 cells per condition were resuspended in 100 \u00b5L of FACS buffer and Fc-blocked with Human TruStain FcX (BioLegend 422302; 10 min at RT). Viability was assessed with LIVE/DEAD Fixable Aqua Dead Cell Stain (Thermo Fisher L34966; excitation 405 nm, 15 min at RT in the dark). Surface staining was then performed for 30 min at 4 \u00b0C in the dark with a pre-titrated panel: anti-CD34-BUV395 (BD Biosciences, clone 581, catalog 563778; excitation by the ultraviolet 355 nm laser) and anti-CD11b-FITC (BioLegend, clone ICRF44, catalog 301330; excitation by the blue 488 nm laser). Cells were washed twice and resuspended in 300 \u00b5L of FACS buffer for acquisition " + C("sutherland1996", "civin1984cd34", "solovjov2005cd11b") + ".")
P("Single-color compensation controls were prepared on UltraComp eBeads for each antibody and on ArC Amine Reactive Compensation beads for the viability dye, and a compensation matrix was calculated and verified. Fluorescence-minus-one (FMO) controls for CD34 and CD11b were prepared to set positive-population gates objectively. Data were acquired on a BD FACSymphony A5 cytometer equipped with ultraviolet (355 nm), violet (405 nm), and blue (488 nm) lasers; BUV395 was collected through a 379/28 filter off the UV laser, Aqua through a 525/50 filter off the violet laser, and FITC through a 530/30 filter off the blue laser. A minimum of 20,000 live-cell events was collected per condition. Analysis was performed in FlowJo v10.9 using a sequential gating strategy: (i) elimination of debris on a forward-scatter-area (FSC-A) versus side-scatter-area (SSC-A) plot; (ii) doublet exclusion on an FSC-height (FSC-H) versus FSC-A plot to retain singlets; (iii) exclusion of LIVE/DEAD-positive dead cells to retain the live fraction; and (iv) quantification of CD34-positive and CD11b-positive populations on a CD34 (BUV395) versus CD11b (FITC) bivariate plot, with single-parameter histograms generated for each marker. The CD11b:CD34 ratio was computed per condition as the quotient of the percentages of live singlets in the CD11b-positive and CD34-positive gates. Three independent biological replicates (distinct donors) were analyzed; group comparisons used paired t-tests across matched donors.")

H2("1.2.11 High-throughput drug screening")
P("Ex vivo drug-sensitivity data were obtained from the BeatAML functional-genomics resource, which is part of the multi-institutional cohort and was generated at the Munich Leukemia Laboratory. In the BeatAML high-throughput screen, freshly isolated primary mononuclear cells from each patient sample are dispensed into 384-well plates and exposed to a panel of small-molecule inhibitors, each tested across seven graded concentrations spanning a roughly 10,000-fold range. After three days of ex vivo culture, viability in each well is measured by a CellTiter-Glo luminescent assay and normalized to vehicle-treated wells, and a four-parameter logistic curve is fit to the dose-response data for each drug to derive the IC50 and the area under the dose-response curve (AUC). For this analysis, the per-drug IC50 and AUC values were compared between del(20q) and cytogenetically diploid samples by two-tailed Mann-Whitney U test with Benjamini\u2013Hochberg correction " + C("benjamini1995") + ", and drug-class enrichment was assessed by one-sided Wilcoxon rank-sum tests.")

H2("1.2.12 OncoKB druggable pathway analysis")
P("The 719 clonality-correlated DEGs (Section 1.2.3) were cross-referenced against the OncoKB precision oncology knowledge base " + C("chakravarty2017oncokb", "suehnholz2024oncokb") + " to identify genes annotated as cancer-associated (oncogenes, tumor suppressors, or oncogene-and-TSG dual-function) and to determine the availability of FDA-approved or investigational therapeutics targeting the corresponding gene products. The subset represented on the OncoKB heme panel and falling within established myeloid-relevant druggable pathways (BCL-2 family, HDAC, proteasome, DNA methylation) was tabulated, with target-gene and available-therapeutic counts reported per pathway.")

H2("1.2.13 Statistical analysis")
P("All analyses were performed in R version 4.3.2 with the tidyverse " + C("wickham2019") + ", rstatix, ggplot2, and survival packages, and in GraphPad Prism version 10. For two-group comparisons, two-tailed Welch's t-tests were used for normal data and Mann-Whitney U tests for non-normal data; normality was assessed by the Shapiro-Wilk test. For multi-group comparisons, one-way ANOVA with Tukey's HSD was used for normal data and Kruskal-Wallis with Dunn's post-hoc test for non-normal data. Paired t-tests were used for paired conditions across biological replicates, including the flow-cytometry CD11b:CD34 comparisons. P-values are two-sided with significance denoted: ns, P \u2265 0.05; *, P < 0.05; **, P < 0.01; ***, P < 0.001; ****, P < 0.0001. Data are mean \u00b1 SEM unless otherwise specified.")

doc.save(os.path.join(BUILD_DIR,'part1.docx'))
ct.save_state(os.path.join(BUILD_DIR,'cite_state.pkl'))
print(f"Part 1 saved — paragraphs: {len(doc.paragraphs)}; refs assigned so far: {len(ct._order)}")
