"""
Results (figures + captions)

Document-build pipeline (Python). Paths resolve to the repository root so the
package is portable. Figure images are expected in <repo>/figures/ and output
lands in <repo>/build/.
"""
import os
HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(HERE)              # repository root (python/ -> root)
FIG_DIR   = os.path.join(BASE, 'figures')
BUILD_DIR = os.path.join(BASE, 'build')
os.makedirs(BUILD_DIR, exist_ok=True)
os.makedirs(FIG_DIR,  exist_ok=True)

"""FULL Chapter 1 build — Part 2: Results (continues full_part1.docx)."""
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import citemod as ct

doc = Document(os.path.join(BUILD_DIR,'part1.docx'))
ct.load_state(os.path.join(BUILD_DIR,'cite_state.pkl'))
C = ct.C

def H1(t):
    p = doc.add_heading(t, level=1); p.paragraph_format.first_line_indent = Inches(0); return p
def H2(t):
    p = doc.add_heading(t, level=2); p.paragraph_format.first_line_indent = Inches(0); return p
def P(t):
    p = doc.add_paragraph(t); p.paragraph_format.line_spacing = 2.0; return p
def PB():
    doc.add_page_break()

def _set_alt_text(inline_pic_paragraph, alt):
    # set alt text (accessibility) on the most recently added inline picture
    from docx.oxml.ns import qn
    blips = inline_pic_paragraph._p.findall('.//' + qn('wp:docPr'))
    for dp in blips:
        dp.set('descr', alt); dp.set('title', alt)

_bm_counter = [2000]
def _bookmark_name(label):
    # "Figure 1" -> "fig_2_1"
    return "fig_" + label.split()[1].replace('.', '_')
def add_caption_bookmark(paragraph, label):
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    name = _bookmark_name(label)
    bid = str(_bm_counter[0]); _bm_counter[0] += 1
    start = OxmlElement('w:bookmarkStart'); start.set(qn('w:id'), bid); start.set(qn('w:name'), name)
    end = OxmlElement('w:bookmarkEnd'); end.set(qn('w:id'), bid)
    paragraph._p.insert(0, start)
    paragraph._p.append(end)

def insert_figure(path, label, caption, width=5.8):
    pic = doc.add_paragraph(); pic.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pic.paragraph_format.first_line_indent = Inches(0)
    pic.paragraph_format.space_before = Pt(6); pic.paragraph_format.space_after = Pt(3)
    pic.add_run().add_picture(path, width=Inches(width))
    _set_alt_text(pic, label + ". " + caption)
    cap = doc.add_paragraph(); cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    try:
        cap.style = doc.styles['Caption']
    except KeyError:
        pass
    cap.paragraph_format.first_line_indent = Inches(0)
    cap.paragraph_format.line_spacing = 1.15; cap.paragraph_format.space_after = Pt(12)
    r = cap.add_run(label + ". "); r.bold = True; r.font.size = Pt(11); r.italic = False
    r2 = cap.add_run(caption); r2.italic = True; r2.font.size = Pt(11)
    add_caption_bookmark(cap, label)

def insert_placeholder(label, descr):
    box = doc.add_paragraph(); box.alignment = WD_ALIGN_PARAGRAPH.CENTER
    box.paragraph_format.first_line_indent = Inches(0)
    box.paragraph_format.space_before = Pt(10); box.paragraph_format.space_after = Pt(3)
    for i, line in enumerate(["\u2550" * 55,
                              "  [ FIGURE PLACEHOLDER \u2014 TO BE INSERTED: " + label + " ]",
                              "\u2550" * 55]):
        run = box.add_run(line); run.font.name = 'Courier New'; run.font.size = Pt(10); run.bold = True
        if i < 2:
            box.add_run("\n")
    cap = doc.add_paragraph(); cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    try:
        cap.style = doc.styles['Caption']
    except KeyError:
        pass
    cap.paragraph_format.first_line_indent = Inches(0)
    cap.paragraph_format.line_spacing = 1.15; cap.paragraph_format.space_after = Pt(12)
    r = cap.add_run(label + ". "); r.bold = True; r.font.size = Pt(11); r.italic = False
    r2 = cap.add_run(descr); r2.italic = True; r2.font.size = Pt(11)
    add_caption_bookmark(cap, label)

F = FIG_DIR + os.sep

PB()
H1("1.3 Results")

# ---- 2.3.1 cohort + phenotype framing ----
H2("1.3.1 Cohort assembly and the cytogenetic landscape of myeloid neoplasms")
P("We first established the cytogenetic context within which del(20q) occurs by assembling and karyotyping the multi-institutional cohort of 4,751 MN patients, of whom 2,022 had evaluable cytogenetic data; 93.9% harbored at least one clonal abnormality (Figure 1). Consistent with the literature " + C("haase2007", "schanz2012") + ", the recurrent abnormalities were dominated by unbalanced losses and gains. Across the copy-number-resolved subset (n = 1,247), the most frequent deletions were del(5q) at 30.1% and del(7q) at 21.2%, followed by del(20q) and del(18q) at 7.0% each, with loss of the Y chromosome (\u2212Y) in 5.0%; trisomy 8 was the most common recurrent gain. The genome-wide circos representation tallied 2,212 copy-number losses, 2,101 gains, and 672 regions of copy-neutral loss of heterozygosity, situating del(20q) as a recurrent but comparatively uncommon deletion occurring against a backdrop of more frequent 5q and 7q loss.")
insert_figure(F + 'fig01_cytogenetic_landscape.jpg', "Figure 1",
    "Cytogenetic landscape of the multi-institutional MN cohort. Assembled from the Cleveland Clinic Foundation (n = 1,248), Munich Leukemia Laboratory (n = 1,923), TCGA (n = 200), BEAT-AML (n = 482), and open-source datasets (n = 898). Of 2,022 patients with cytogenetic data, 93.9% were abnormal. The circos plot summarizes 2,212 losses, 2,101 gains, and 672 CN-LOH events (n = 1,247 with copy-number resolution). del(5q) and del(7q) are the most frequent deletions, followed by del(20q).")

H2("1.3.2 Clinical and morphologic phenotype of the del(20q) subset")
P("Having situated del(20q) within the landscape, we characterized the phenotype of the del(20q) subset in detail (Figure 2). del(20q) was distributed across the MN spectrum but reached its highest relative frequency in MPN, consistent with its recognized association with myeloproliferative disease, while within the MDS-classified patients it occurred predominantly as an isolated lesion in approximately 50% of cases (n = 125). Morphologically, del(20q) cases showed a distinctive dysplasia profile concentrated in the erythroid and megakaryocytic lineages, with megakaryocytic atypia and emperipolesis prominent, in contrast to the more balanced trilineage dysplasia of cytogenetically diploid disease (dysplasia comparison: diploid n = 1,040 versus del(20q) n = 39). In our disease-classification breakdown, the del(20q) cohort was 72% MDS and 18% MDS/MPN, with the remainder distributed across MPN and AML. This indolent, lineage-skewed phenotype is concordant with the favorable prognosis of isolated del(20q) and frames it as a disease of altered differentiation rather than of proliferative excess.")
insert_figure(F + 'fig02_clinical_phenotype.jpg', "Figure 2",
    "Clinical and morphologic phenotype of del(20q). del(20q) reaches its highest relative frequency in MPN and occurs as an isolated lesion in roughly 50% of cases (n = 125). Dysplasia is concentrated in erythroid and megakaryocytic lineages with megakaryocytic atypia and emperipolesis (diploid n = 1,040 vs del(20q) n = 39). The cohort is predominantly MDS (72%) and MDS/MPN (18%).")

H2("1.3.3 Detection, the Common Deleted Region, and candidate genes")
P("del(20q) was detected by complementary modalities, conventional karyotype, interphase FISH with a 20q12 probe, and SNP array, the last providing the breakpoint resolution required to delineate the CDR (Figure 3). SNP-array breakpoint mapping across the deleted cases defined a Common Deleted Region spanning 20q11.22 to 20q13.13, approximately 2.6 Mb and containing 126 protein-coding genes (Figure 5). The CDR contains several genes with prior tumor-suppressor associations, including L3MBTL1, a Polycomb-related chromatin factor " + C("macgrogan2004", "trojer2007") + ", the cell-cycle transcription factor MYBL2 " + C("heinrichs2013") + ", the Hippo-pathway kinase STK4 " + C("avruch2012") + ", and the phosphatase PTPN1 " + C("bollu2017") + ", none of which alone accounts for the del(20q) phenotype, motivating the unbiased analysis that follows.")
insert_figure(F + 'fig03_detection_methods.jpg', "Figure 3",
    "Detection of del(20q) by karyotype, interphase FISH (20q12 probe), and SNP array. SNP-array log2 ratio plots provide the breakpoint resolution used for CDR delineation.")

P("Before pursuing a haploinsufficiency model, we tested whether del(20q) acts through gene rescue, that is, by removing a recurrent germline or somatic 20q lesion (Figure 4). Targeted next-generation sequencing of a panel of more than 40 recurrently mutated myeloid genes across del(20q) cases (n = 79) and diploid controls (n = 2,766) revealed no recurrent pathogenic germline variant on 20q and no recurrent somatic 20q lesion eliminated by the deletion; the most frequently mutated genes are displayed in the figure, excluding both germline and somatic gene rescue " + C("revy2019somatic", "polprasert2015ddx41", "tesi2017samd9l") + ". The somatic mutational landscape of del(20q) cases instead broadly mirrored that of diploid disease, with no del(20q)-specific recurrent mutation. The common myeloid mutations occurred less frequently in del(20q): TET2 (10.6% vs 27.4%), ASXL1 (9.2% vs 19.5%), and SF3B1 (6.4% vs 18.7%) were all significantly lower (P < 0.05), with a non-significant trend for U2AF1 (P = 0.12). The absence of any recurrent germline or somatic 20q lesion, together with the conserved single-copy loss and the absence of second-hit point mutations in retained CDR genes, excludes gene rescue and allelic-imbalance-by-mutation models and points to haploinsufficiency of a 20q tumor suppressor as the operative mechanism.")
insert_figure(F + 'fig04_no_gene_rescue.jpg', "Figure 4",
    "No evidence of gene rescue in del(20q). A panel of more than 40 recurrently mutated myeloid genes across del(20q) (n = 79) and diploid (n = 2,766) cases reveals no recurrent germline or somatic 20q lesion; the most frequently mutated genes are shown. Common myeloid mutations are significantly less frequent in del(20q): TET2 10.6% vs 27.4%, ASXL1 9.2% vs 19.5%, SF3B1 6.4% vs 18.7% (all P < 0.05); U2AF1 trend P = 0.12.")
insert_figure(F + 'fig05_CDR_definition.jpg', "Figure 5",
    "The del(20q) Common Deleted Region. SNP-array breakpoint mapping defines a CDR spanning 20q11.22\u201320q13.13 (~2.6 Mb, 126 protein-coding genes), within which candidate tumor suppressors include L3MBTL1, MYBL2, STK4, and PTPN1.")

H2("1.3.4 Clonality-corrected differential expression isolates copy-number-dependent genes")
P("We first asked whether the genes retained on the deleted segment are expressed at reduced levels in del(20q) marrow relative to copy-number-diploid controls. Of the 126 CDR genes, 101 were underexpressed at FDR < 0.05 (Figure 6), the pattern expected when a single retained allele fails to maintain normal output. Differential expression by itself does not separate a true dosage effect from differences in clonal burden between patients, so each gene's expression was regressed on the patient-specific del(20q) clonal fraction and extrapolated to pure clonal dosage. Sixty-nine genes held a copy-number dependence at R\u00b2 > 0.1; the steepest slopes were TOMM34 (R\u00b2 = 0.66) and PIGT (R\u00b2 = 0.49) (Figure 7). Genes that behaved this way were retained for downstream analysis; the remainder, whose expression moved for reasons unrelated to clonal fraction, were set aside.")
insert_figure(F + 'fig06_volcano_haploinsufficiency.jpg', "Figure 6",
    "Haploinsufficiency of retained genes within the deleted region. Differential expression in del(20q) versus copy-number-diploid cases; genes within the common deleted region are predominantly underexpressed, the expected signature of a single retained copy.")
insert_figure(F + 'fig07_gene_dose_regressions.jpg', "Figure 7",
    "Gene-dose dependence of CDR gene expression. Expression of representative CDR genes against del(20q) copy-number loss; 69 genes retain copy-number dependence at R\u00b2 > 0.1, the steepest being TOMM34 (R\u00b2 = 0.66) and PIGT (R\u00b2 = 0.49).")

H2("1.3.5 del(20q) does not define a transcriptionally distinct subgroup")
P("We next asked whether del(20q) cases form a coherent transcriptional cluster. Unsupervised hierarchical clustering with Ward's linkage failed to segregate del(20q) cases from diploid disease (Figure 8), and K-means clustering (k = 5) with PCA likewise showed del(20q) cases distributed within the diploid transcriptional space rather than forming a discrete cluster (Figure 9). This indicates that del(20q) does not impose a globally distinct transcriptome but instead exerts a focal, dosage-driven effect on a limited set of genes, reinforcing the need for a targeted, network-based approach rather than whole-transcriptome clustering to identify the driver.")
insert_figure(F + 'fig07_no_wards_clustering.jpg', "Figure 8",
    "Hierarchical clustering (Ward's linkage) does not segregate del(20q) from diploid cases, indicating the absence of a globally distinct del(20q) transcriptome.")
insert_figure(F + 'fig08_diploid_clustering.jpg', "Figure 9",
    "K-means clustering (k = 5) with PCA shows del(20q) cases distributed within the diploid transcriptional space rather than forming a discrete cluster.")

P("Extending the dosage analysis genome-wide, 2,042 genes were differentially expressed between del(20q) and diploid cases at FDR < 0.05, of which 719 retained copy-number dependence at R\u00b2 > 0.1 (Figure 10). Subcellular-localization annotation showed that of the 1,916 non-CDR DEGs, 63.6% were intracellular, 16.5% surface, and 19.9% secreted, while of the 126 CDR genes, 65.9% were intracellular, 11.1% surface, and 23.0% secreted; the genome-wide circos showed 659 over- and 1,245 under-expressed genes. This 719-gene clonality-correlated signature constitutes the input for the downstream network and druggability analyses.")
insert_figure(F + 'fig09_719_DEGs_genome.png', "Figure 10",
    "Genome-wide clonality-correlated differential expression. Of 2,042 DEGs (FDR < 0.05), 719 retain copy-number dependence (R\u00b2 > 0.1). Subcellular distribution: non-CDR DEGs (n = 1,916) 63.6% intracellular / 16.5% surface / 19.9% secreted; CDR genes (n = 126) 65.9% / 11.1% / 23.0%. Circos: 659 over- and 1,245 under-expressed genes.")

# ---- 2.3.6 PANDA->PHF20, Markov->HDAC2 (kept from prior, with C()) ----
H2("1.3.6 PANDA identifies PHF20 as a central hub and Markov analysis identifies HDAC2")
P("With the candidate pool narrowed to 69 CN-dependent CDR genes, and with hierarchical clustering having failed to reveal a coordinated subgroup, we used network-based regulatory analysis to identify which gene exerts the greatest regulatory influence. As detailed in Section 1.2.4, this proceeded in two stages with complementary logic: the PANDA message-passing algorithm first assimilated transcription-factor binding motifs (DoRothEA), protein\u2013protein interactions (HumanNet v3), and gene\u2013gene co-expression (MLL cohort, n = 772) into a single denoised regulatory network, after which the converged network was analyzed as a Markov chain to rank genes by the stationary distribution of a random walk (PageRank). PANDA asks which genes occupy structurally central, interaction-reinforced positions; the Markov analysis asks through which genes regulatory flow ultimately concentrates.")
P("PANDA updates each TF\u2192gene edge weight W_ij through a Responsibility message R_ij, which compares the protein-interaction partners of TF i to the TFs currently regulating gene j and so injects proteomic evidence, and an Availability message A_ij, which compares the target profile of TF i to the co-expression neighborhood of gene j and so injects transcriptomic evidence. These are averaged as W\u0303_ij = 0.5\u00b7A_ij + 0.5\u00b7R_ij and applied under a regularized update W_ij^(t+1) = (1\u2212\u03b1)\u00b7W_ij^(t) + \u03b1\u00b7W\u0303_ij until convergence (Figure 11), so that an edge survives only where motif, interaction, and co-expression evidence agree. A direct consequence of incorporating the PPI prior is that proteins embedded in dense, well-connected complexes accumulate high integrated connectivity. PHF20, as a scaffold reader of the MOF/NSL complex that physically engages KAT8/MOF, the KANSL subunits, WDR5, and p53, carries exactly this dense interaction signature, and in the converged PANDA network it emerged as a central hub among the CDR candidates, occupying a high-degree, high-betweenness position that the message-passing propagated from its protein-complex membership rather than from a large direct transcriptional out-degree.")
insert_figure(F + 'fig10_PANDA_methodology.jpg', "Figure 11",
    "PANDA methodology integrates protein\u2013protein interaction and transcriptomic data. Each TF\u2192gene edge is updated by a Responsibility message from TF\u2013TF PPI partners (proteomic evidence) and an Availability message from gene\u2013gene co-expression (transcriptomic evidence), combined and regularized iteratively to convergence. The PPI integration causes densely interacting complex-forming proteins such as the MOF/NSL scaffold PHF20 to emerge as central hubs.")
P("The PPI and RNA-seq heatmap inputs reveal the structure of the underlying signal in the 69 CDR genes (Figure 12). The PPI heatmap shows discrete blocks of densely interacting subsets corresponding to known protein complexes (chromatin regulators, cell-cycle components, ribosomal and proteostatic genes), while the RNA-seq co-expression heatmap shows broader, more diffuse patterns with both positively and negatively correlated clusters. PANDA integrates these evidence types so that both physical interaction and expression coordination contribute to edge weights, each constraining the other; PHF20's position within the tightly interconnected chromatin-regulator block of the PPI heatmap is the structural basis for its emergence as a PANDA hub.")
insert_figure(F + 'fig11_PANDA_heatmaps.jpg', "Figure 12",
    "PANDA interim heatmaps from the 69 CN-dependent CDR genes. Left: PPI heatmap (HumanNet v3) showing discrete blocks of densely interacting protein subsets, including the chromatin-regulator block containing PHF20. Right: RNA-seq co-expression heatmap (MLL cohort) showing positively (red) and negatively (blue) correlated clusters.")
P("We next analyzed the converged network as a Markov chain (Section 1.2.4.C). Converting the weighted network to a row-stochastic transition matrix and estimating the stationary distribution of a damped random walk by MCMC (damping factor 0.85; 1,000 iterations) ranks every gene by PageRank centrality, the fraction of time a random walker spends at each node and therefore the degree to which regulatory flow concentrates through it. The highest-ranked nodes by this Markov criterion were the transcription factors E2F1 and MYBL2 and, prominently, the chromatin eraser HDAC2, which emerged as the top-ranked chromatin-modifying hub in the network. PHF20 itself ranked comparatively low on this transcription-flow metric (46th of 123 ranked genes; approximately the 9.8th percentile of the high-confidence network). That PHF20 ranks low here follows from how it works. PageRank rewards high transcriptional out-degree, which is a property of transcription factors and enzymes. PHF20 is a chromatin reader that recruits an acetyltransferase complex rather than transactivating many genes itself, so it has few outgoing edges and a low stationary probability. A low Markov rank is therefore what we would expect for a complex-based epigenetic regulator, and it weighs against treating PHF20 as a master transcription factor.")
P("The two rankings pick out different genes. PANDA, which uses protein-interaction data, ranks PHF20 highly because it sits inside the MOF/NSL acetyltransferase complex. The Markov ranking, which depends on transcriptional flow, ranks the eraser HDAC2 highly because of its broad reach. PHF20 helps write and HDAC2 erases the same H4K16 mark (Section 1.3.7), so the two are not rival candidates but the two ends of one acetylation switch. HDAC2 is the enzymatically tractable end, and it is the one we carried into the drug screen (Section 1.3.13).")
P("To translate the network analysis into a single prioritized candidate, we superimposed an eight-feature curated selection grid (Figure 13): haploinsufficiency, gene-dose effect, master-regulator/hub status, HSC expression, known TSG status, decreased expression in MN, implication in other malignancies, and murine embryonic lethality. Of the network-prioritized candidates, PHF20 was the only gene satisfying all eight criteria. ITCH and TGIF2 satisfied five each; RALGAPB and PIGT five; CEBPB six. PHF20 had documented evidence for all eight: established haploinsufficiency, gene-dose effect in our clonality-corrected analysis, central-hub status in the PANDA network, detectable HSC expression, tumor-suppressor function via p53 stabilization, decreased expression in our del(20q) cohort, implication in lung adenocarcinoma and hepatocellular carcinoma, and perinatal lethality in Phf20-null mice. This convergence of unbiased network prioritization and curated biological criteria identifies PHF20 as the single most rational driver candidate, with HDAC2, the opposing eraser surfaced by the Markov analysis, as the paired therapeutic target.")
insert_figure(F + 'fig12_feature_selection_PHF20.jpg', "Figure 13",
    "Multi-feature selection identifies PHF20 as the only CDR candidate satisfying all eight prioritization criteria: haploinsufficiency, gene-dose effect, master GRN regulator/hub, present in HSC, known TSG, decreased expression in MN, implicated in other malignancies, and embryonic lethality. ITCH, TGIF2, RALGAPB, CEBPB, and PIGT each satisfy five to six criteria. PHF20 is prioritized as the driver; HDAC2, the top Markov/MCMC-ranked eraser node, is its paired therapeutic target.")

# ---- 2.3.7 PHF20 biology ----
H2("1.3.7 PHF20 expression across the hematopoietic hierarchy and its biochemical role")
P("Having nominated PHF20, we examined its expression across hematopoiesis and its mechanism. Single-cell expression data from the Human Protein Atlas show PHF20 expressed across the hematopoietic hierarchy with enrichment in immature progenitor populations (Figure 14), consistent with a role in the stem/progenitor compartment where del(20q) clones arise. Biochemically, PHF20 is a scaffold and reader subunit of the MOF/NSL (KAT8) histone-acetyltransferase complex, the principal depositor of histone H4 lysine-16 acetylation (H4K16ac), and it additionally stabilizes p53 through Tudor-domain recognition of dimethylated lysine 370 " + C("smith2005mof", "cui2012phf20", "klein2016phf20") + ". H4K16ac is dynamically opposed by the class I histone deacetylases HDAC1 and HDAC2, establishing a writer-eraser equilibrium that sets the steady-state acetylation level and, through it, the balance between an open, differentiation-permissive chromatin state and a compact, stem-cell-associated state (Figure 15). Within this framework, PHF20 haploinsufficiency weakens the writer arm, shifting the equilibrium toward reduced H4K16ac and a differentiation-restrictive chromatin state, while leaving the cell selectively dependent on, and therefore vulnerable to inhibition of, the opposing HDAC2 eraser.")
insert_figure(F + 'fig13_PHF20_expression_lineage.jpg', "Figure 14",
    "PHF20 expression across the hematopoietic hierarchy (Human Protein Atlas single-cell data), with enrichment in immature progenitor populations.")
insert_figure(F + 'fig14_PHF20_H4K16_mechanism.jpg', "Figure 15",
    "PHF20 within the MOF/NSL\u2013H4K16ac axis. PHF20 scaffolds the MOF (KAT8) acetyltransferase that deposits H4K16ac, opposed by HDAC1/2. The acetylation state sets a differentiation gradient (mature markers CD71, CD235a, CD11b, CD33 vs immature CD34, CD117, CD133). PHF20 also stabilizes p53 via K370me2 recognition.")
P("The predicted regulatory overlap between PHF20 and HDAC2 is supported by expression analysis: PHF20 and HDAC2 expression are correlated across the cohort, and a shared top-100-gene regulatory signature links the two nodes (Figure 16), consistent with their action on a common set of H4K16ac-dependent loci and providing the molecular basis for the synthetic-lethal relationship pursued therapeutically below.")
insert_figure(F + 'fig15_PHF20_HDAC2_overlap.jpg', "Figure 16",
    "PHF20\u2013HDAC2 regulatory overlap. Scatter of PHF20 versus HDAC2 expression and a shared top-100-gene regulatory signature heatmap, consistent with convergent action on H4K16ac-dependent loci.")

# ---- 2.3.8-2.3.10 functional ----
H2("1.3.8 siRNA knockdown of PHF20 in cell lines and primary HSPCs")
P("To model del(20q)-associated PHF20 haploinsufficiency, we performed siRNA knockdown (Figure 17). RT-qPCR confirmed knockdown across models at 25 nM: residual PHF20 expression was approximately 18% in TF1 (P < 0.0001), 75% in THP-1 (P = 0.06), 50% in K562 (P < 0.0001), and 35% in normal bone marrow CD34+ HSPCs (P < 0.0001). The partial, dose-dependent reduction in primary HSPCs (to ~35% residual) approximates the single-copy-loss dosage of del(20q), making it a faithful model of the haploinsufficient state.")
insert_figure(F + 'fig16_qPCR_validation.jpg', "Figure 17",
    "RT-qPCR validation of PHF20 knockdown. Residual PHF20 expression at 25 nM siRNA: TF1 ~18% (P < 0.0001), THP-1 ~75% (P = 0.06), K562 ~50% (P < 0.0001), NBM CD34+ ~35% (P < 0.0001). Relative to NTC by 2^\u2212\u0394\u0394Ct, normalized to ACTB.")

H2("1.3.9 PHF20 knockdown expands clonogenic progenitors")
P("In CFU assays of PHF20-knockdown CD34+ HSPCs (Figure 18), PHF20 loss increased colony output in both major lineages, with myeloid (CFU-GM) colonies rising from 34 to 60 (P = 0.02) and erythroid (BFU-E/CFU-E) colonies rising from 60 to 140 (P = 0.04), the erythroid expansion exceeding the myeloid. The increase in clonogenic capacity indicates that PHF20 haploinsufficiency confers a proliferative/self-renewal advantage at the progenitor level, the cellular correlate of the clonal advantage conferred by del(20q), and the erythroid-predominant expansion mirrors the erythroid-skewed dysplasia of the del(20q) clinical phenotype (Section 1.3.2).")
insert_figure(F + 'fig17_CFU_assay.jpg', "Figure 18",
    "PHF20 knockdown expands clonogenic progenitors. CFU-GM rises from 34 to 60 (P = 0.02) and erythroid BFU-E/CFU-E from 60 to 140 (P = 0.04); erythroid expansion exceeds myeloid. MethoCult H4434, day 14, three donors.")

H2("1.3.10 Increased clonogenicity without maturation predicts a differentiation block")
P("The combination of expanded clonogenic output (Section 1.3.9) with the immature, erythroid/megakaryocytic-skewed phenotype of del(20q) disease (Section 1.3.2) predicts that PHF20 loss expands progenitors that fail to complete maturation, that is, a differentiation block superimposed on a proliferative advantage. This prediction is tested directly at the protein and immunophenotypic levels in Sections 1.3.11 and 2.3.12.")

# ---- 2.3.11 Western placeholder (Fig 2.18) ----
H2("1.3.11 PHF20 knockdown reduces H4K16 acetylation (Western blot)")
P("To confirm that PHF20 loss reduces MOF-dependent histone acetylation at the protein level, PHF20 and H4K16ac were quantified by Western blot in PHF20-knockdown versus control cells, with PHF20 detected at approximately 115 kDa and H4K16ac at approximately 11.4 kDa, normalized to \u03b2-actin and total histone H4 respectively (Section 1.2.8). This experiment is ongoing; the blot and densitometry will be added when the data are complete.")
insert_placeholder("Figure 19",
    "PHF20 knockdown reduces H4K16 acetylation. [Placeholder for Western blot and densitometry.] Anti-PHF20 (~115 kDa) and anti-H4K16ac (~11.4 kDa), with \u03b2-actin and total H4 loading controls; PHF20-KD versus NTC across biological replicates. Blot and densitometry to be added.")

# ---- 2.3.12 Flow placeholder (Fig 2.19) ----
H2("1.3.12 PHF20 knockdown impairs myeloid maturation (flow cytometry)")
P("To test the predicted differentiation block directly, the immature progenitor (CD34-positive) and mature myelomonocytic (CD11b-positive) compartments were quantified by multiparameter flow cytometry in PHF20-knockdown versus control normal bone marrow CD34+ HSPCs after seven days of cytokine-driven maturation (Section 1.2.10), using anti-CD34-BUV395 (clone 581, UV 355 nm laser) and anti-CD11b-FITC (clone ICRF44, blue 488 nm laser), with sequential gating on FSC-A/SSC-A, singlets (FSC-H vs FSC-A), and live cells, followed by CD34-versus-CD11b quantification and single-parameter histograms for each marker. This experiment is ongoing; the bivariate plots and histograms will be added when the data are complete. During assay development an initial run returned 0% CD34 positivity in the normal control, which we traced to the ultraviolet 355 nm laser line needed to excite BUV395 being absent or misassigned. Valid CD34 detection requires the UV laser to be configured correctly, as specified in the acquisition protocol.")
insert_placeholder("Figure 20",
    "PHF20 knockdown impairs myeloid maturation. [Placeholder for flow cytometry.] Gating: FSC-A/SSC-A \u2192 singlets (FSC-H vs FSC-A) \u2192 live (LIVE/DEAD Aqua-negative) \u2192 CD34-BUV395 vs CD11b-FITC bivariate plot with single-parameter histograms. PHF20-KD versus normal bone marrow control; CD11b:CD34 ratio per condition across three donors. Plots and histograms to be added.")

# ---- 2.3.13 Drug screen (Fig 2.20) ----
H2("1.3.13 High-throughput drug screening reveals preferential del(20q) sensitivity to HDAC inhibition")
P("Having established PHF20 as a haploinsufficient tumor suppressor producing coupled proliferation and differentiation arrest, and having identified HDAC2 as the dominant eraser node opposing it, we screened 199 compounds across seven concentrations against patient-derived primary MN samples to identify agents that selectively exploit the resulting chromatin vulnerability (Figure 21). Four compounds emerged with substantially enhanced activity in del(20q) relative to diploid samples: panobinostat (a pan-HDAC inhibitor), venetoclax and ABT-737 (BCL-2 family inhibitors), and BEZ235 (a dual PI3K/mTOR inhibitor).")
insert_figure(F + 'fig18_drug_screen.jpg', "Figure 21",
    "High-throughput drug screen of 199 compounds against patient-derived MN samples. Panobinostat (HDAC inhibitor), venetoclax and ABT-737 (BCL-2 inhibitors), and BEZ235 (PI3K/mTOR) show preferential activity in del(20q) versus diploid samples.")
P("The emergence of panobinostat provides direct empirical validation of the HDAC2 node identified by the Markov/MCMC analysis in Section 1.3.6. Panobinostat is a pan-HDAC inhibitor with potent, low-nanomolar activity against the class I deacetylases HDAC1 and HDAC2, the principal erasers of H4K16 acetylation; the gene whose network centrality the random-walk analysis ranked at the top of the chromatin-modifying nodes is therefore precisely the gene product whose pharmacologic inhibition shows the strongest preferential activity in del(20q) cells. The screen lines up with the network result: PANDA had pointed to PHF20 on the writer side and the Markov ranking to HDAC2 on the eraser side, and the compound that best separates del(20q) cells from controls inhibits HDAC2. Mechanistically, the synthetic lethality follows from the writer-eraser equilibrium: in del(20q) cells the writer arm is weakened by PHF20 haploinsufficiency, and inhibiting the over-represented HDAC2 eraser shifts the equilibrium toward an H4K16-hyperacetylated state that PHF20-deficient cells cannot buffer, simultaneously eliminating the clone and, per Section 1.3.12, relieving the differentiation block. The independent emergence of venetoclax and ABT-737 suggests a parallel vulnerability to apoptotic priming via BCL-2 perturbation, consistent with loss of PHF20-dependent p53 stabilization, while BEZ235 suggests PI3K/AKT pathway sensitivity, consistent with PHF20's role in p53\u2013AKT signaling " + C("cui2012phf20") + ".")

# ---- 2.3.14 OncoKB (Fig 2.21) ----
H2("1.3.14 OncoKB druggability analysis nominates HDAC2 as the actionable node")
P("To place the drug-screen result in a genome-wide druggability framework, the 719 clonality-correlated DEGs were cross-referenced against OncoKB (Figure 22). Of the 719 genes, 82 were annotated cancer genes: 27 tumor suppressors, 26 oncogenes, 11 with insufficient evidence, 4 neither, and 3 dual-function.")
insert_figure(F + 'fig19_OncoKB_druggable.jpg', "Figure 22",
    "OncoKB druggability analysis of the 719-gene signature. 82 of 719 are annotated cancer genes (27 TSG, 26 oncogene, 11 insufficient, 4 neither, 3 dual). Four myeloid-relevant druggable pathways are represented: HDAC (1 target, 8 drugs \u2014 the largest arsenal; target = HDAC2), DNA methylation (7 drugs), BCL-2 (6 drugs), and proteasome (5 drugs).")
P("Beyond pathway-level druggability, we characterized the predicted subcellular localization of the differentially expressed gene products to assess the availability of cell-surface targets. Across both the CDR and the broader non-CDR signature the large majority of products were intracellular, with only a small cell-surface fraction (CDR 11.1%; non-CDR 16.5%), indicating few conventional surface immunotherapy targets and supporting an intracellular, epigenetically directed targeting strategy (Figure 23).")
insert_figure(F + 'fig21_subcellular_targets.png', "Figure 23",
    "Predicted subcellular localization of differentially expressed gene products. Distribution across intracellular, secreted, and cell-surface compartments for the non-CDR signature (left) and the CDR (right). The small cell-surface fraction indicates limited conventional surface immunotherapy targets and supports an intracellular, small-molecule and epigenetic targeting strategy.")
P("Stratification by myeloid-relevant druggable pathway revealed four pathways with both target-gene representation and available therapeutics: BCL-2 family (1 target, 6 drugs), DNA methylation (1 target, 7 drugs), HDAC (1 target, 8 drugs), and proteasome (2 targets, 5 drugs). The single HDAC-pathway target gene is HDAC2, the same eraser node independently ranked highest by the Markov/MCMC network analysis (Section 1.3.6) and confirmed by the drug screen (Section 1.3.13); the HDAC pathway emerged with the largest available arsenal (8 agents), providing convergent evidence across network centrality, empirical screening, and pharmacopoeia-wide annotation that HDAC2 inhibition is the most clinically actionable strategy for del(20q) MN. The BCL-2-family pathway, represented by BCL2L1 (encoding BCL-xL), emerges in parallel (6 drugs, including approved venetoclax and investigational ABT-737), aligning with the BH3-mimetic activity in the screen and suggesting that combination HDAC inhibitor plus BCL-2 inhibitor regimens may be additive or synergistic, a hypothesis amenable to direct clinical testing.")

# ---- 1.3.15 Serial cytogenetics / Markov modeling (Fig 1.22) ----
H2("1.3.15 Serial cytogenetics and Markov modeling identify isolated del(20q) as a stable, indolent clonal state")
P("To test whether the favorable-risk behavior of del(20q) is reflected in its clonal dynamics over time, we assembled a serial-cytogenetics cohort of 31 del(20q) patients with two or more dated karyotypes (81 timepoints; median sampling interval 0.33 years). Each timepoint was assigned to one of three ordinal clonal-burden states: isolated del(20q) (state S1), del(20q) accompanied by one or two additional non-complex aberrations (state S2), and complex karyotype with three or more aberrations (state S3). The 48 within-patient consecutive transitions were modeled both as a discrete per-interval transition matrix and as a continuous-time Markov chain, the latter fit by maximum likelihood to accommodate unequal sampling intervals and transitions occurring between observed samples, with patient-level bootstrap confidence intervals (Figure 24).")
P("The estimated one-year transition probabilities showed that isolated del(20q) is a highly stable state, with 0.85 annual persistence and a rare direct progression to complex karyotype (0.02 per year). The intermediate state behaved as a transient, regression-biased branch point: its mean dwell time was under one year, and from it the modeled annual probability of simplifying back to isolated del(20q) (0.53) exceeded the probability of progressing to complex karyotype (0.14). Complex karyotype, by contrast, behaved as an absorbing-like sink (0.85 annual persistence), the single observed exit being most consistent with treatment response rather than spontaneous regression. The mean state dwell times reinforced this picture: 3.9 years for isolated del(20q), 0.8 years for del(20q)-plus-additional, and 6.0 years for complex karyotype.")
insert_figure(F + 'fig22_swimmer.png', "Figure 24",
    "Clonal-state trajectories across 31 del(20q) patients with serial cytogenetics. Each row is one patient and each marker denotes the clonal-burden state at a sampling timepoint (isolated del(20q); del(20q) plus additional aberrations; or complex karyotype) plotted against time from the first cytogenetic study. Isolated del(20q) predominates and persists over follow-up, whereas complex karyotypes, once acquired, are retained.")
P("This longitudinal behavior is concordant with the mechanistic model developed above. A lesion that confers clonal advantage by imposing a differentiation block through gene-dosage reduction, rather than by driving genomic instability, would be expected to generate a clonal state that persists without progressing, which is precisely what the serial cytogenetics show: isolated del(20q) is an indolent, self-perpetuating state rather than an obligate way-station to complex disease. The analysis carries the limitations inherent to interval-censored karyotype data. The cohort is modest (48 transitions, several of them rare and therefore weakly identified), the 20-metaphase resolution quantizes clone fractions in 5% increments and misses small subclones, the ordinal state definition collapses branching subclonal architecture onto a single complexity axis, and cytogenetics alone cannot temporally order del(20q) relative to cooperating point mutations. Integrating serial next-generation sequencing into the same Markov framework would allow the timing of del(20q) acquisition to be tested directly.")

doc.save(os.path.join(BUILD_DIR,'part2.docx'))
ct.save_state(os.path.join(BUILD_DIR,'cite_state.pkl'))
print(f"Part 2 saved — paragraphs: {len(doc.paragraphs)}; refs assigned so far: {len(ct._order)}")
