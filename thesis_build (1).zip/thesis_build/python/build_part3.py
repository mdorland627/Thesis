"""
Discussion, References, page numbering, finalize

Document-build pipeline (Python). Paths resolve to the repository root so the
package is portable. Figure images are expected in <repo>/figures/ and output
lands in <repo>/build/.
"""
import os
HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(HERE)              # repository root (python/ -> root)
FIG_DIR   = os.path.join(BASE, 'figures')
BUILD_DIR = os.path.join(BASE, 'build')
os.makedirs(BUILD_DIR, exist_ok=True)
os.makedirs(FIG_DIR,  exist_ok=True)

"""FULL Chapter 1 build — Part 3: Discussion + References (continues full_part2.docx)."""
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
import citemod as ct

doc = Document(os.path.join(BUILD_DIR,'part2.docx'))
ct.load_state(os.path.join(BUILD_DIR,'cite_state.pkl'))
C = ct.C

def H1(t):
    p = doc.add_heading(t, level=1); p.paragraph_format.first_line_indent = Inches(0); return p
def H2(t):
    p = doc.add_heading(t, level=2); p.paragraph_format.first_line_indent = Inches(0); return p
def P(t):
    p = doc.add_paragraph(t); p.paragraph_format.line_spacing = 2.0; return p
def PB():
    doc.add_page_break()

PB()
H1("1.4 Discussion")

H2("1.4.1 A unified model of del(20q) myeloid neoplasia")
P("This chapter traces del(20q) myeloid neoplasia from cytogenetics to a candidate therapy. Beginning from a recurrent, favorable-risk deletion of unknown driver, we excluded gene-rescue and second-hit mechanisms, established that the lesion acts through gene dosage, and used clonality-corrected expression analysis, an unbiased PANDA network analysis that identified PHF20 as a central protein-interaction hub, a Markov/MCMC centrality analysis that independently identified HDAC2 as the dominant eraser node, and eight-feature biological selection (Figures 5\u201313), followed by functional validation by knockdown (Figures 17\u201320), to arrive at PHF20 as the haploinsufficient driver and HDAC2 as the paired therapeutic target. The model holds that reduced PHF20 dosage weakens the MOF/NSL\u2013H4K16ac writer arm, shifting the chromatin equilibrium toward a stem-cell-associated, differentiation-restrictive state that expands clonogenic progenitors while blocking their maturation, and that this state is selectively vulnerable to inhibition of the opposing HDAC2 eraser. Serial-cytogenetics Markov modeling supports the indolence this model predicts: isolated del(20q) is a stable, self-perpetuating clonal state that only rarely progresses directly to complex karyotype (Figure 24).")

H2("1.4.2 Biological rationale for the PHF20\u2013HDAC2 axis")
P("A notable feature of the analysis is that the two opposing arms of the H4K16 acetylation axis were nominated independently by two different network-centrality methods applied to the same regulatory network, a convergence that substantially de-risks the central hypothesis. PANDA is a protein-interaction\u2013aware data-assimilation method: by passing Responsibility messages derived from the PPI prior, it propagates the dense physical connectivity of protein-complex members into the regulatory network, so that the MOF/NSL scaffold PHF20, which engages KAT8/MOF, the KANSL subunits, WDR5, and p53, accumulates high integrated connectivity and emerges as a central hub. The Markov/MCMC analysis answers a different question: modeling the converged network as a random walk and computing the stationary distribution (PageRank), it ranks genes by the degree to which regulatory flow concentrates through them, a metric that rewards transcriptional out-degree and so elevates broadly-acting effectors. By this criterion the eraser HDAC2 ranks among the highest nodes, while PHF20, a reader-scaffold with low transcriptional out-degree, ranks comparatively low. Rather than being contradictory, the two results are jointly informative: the low Markov rank of PHF20 is the expected signature of an epigenetic, complex-scaffolding mechanism, and would have been a misleading basis for dismissing PHF20 had only flow-centric centrality been used, while the high Markov rank of HDAC2 identifies the transcriptionally dominant eraser through which the H4K16ac axis is enforced. That the writer scaffold and its opposing eraser are surfaced by complementary algorithms, and that the eraser is then validated as the actionable drug target by an unbiased screen, provides a coherence across methods that neither analysis could supply alone.")
P("The synthetic-lethal relationship between PHF20 loss and HDAC inhibition is rooted in the chromatin biology of H4K16 acetylation. H4K16ac is the only single-residue histone acetylation whose deposition is sufficient on its own to disrupt the formation of compact 30-nm chromatin fibers in vitro " + C("shogrenknaak2006", "robinson2008") + ", and its loss promotes a more repressive, heterochromatic state. In hematopoietic cells, the MOF complex, of which PHF20 is a scaffold component, is the principal H4K16 acetyltransferase, and its activity is dynamically opposed by class I HDACs, predominantly HDAC1 and HDAC2 " + C("taunton1996hdac", "valerio2017mof") + ". Genetic loss of MOF/KAT8 in murine hematopoiesis produces severe defects in HSC self-renewal and lineage commitment, with impaired differentiation and aberrant proliferation " + C("valerio2017mof") + ", phenotypes that parallel the consequences of PHF20 knockdown observed here.")
P("PHF20 enters this equilibrium through two roles: as a chromatin reader of methylated lysines that recruits the MOF complex to target loci, and as a direct p53 stabilizer via Tudor-domain recognition of dimethylated lysine 370, competing with MDM2-mediated ubiquitination " + C("cui2012phf20", "badeaux2012phf20", "klein2016phf20") + ". This dual nature explains why PHF20 behaves as a haploinsufficient tumor suppressor across multiple malignancies " + C("jiang2014phf20", "park2018phf20hcc", "park2017phf20nsclc", "zhao2021phf20") + ": its loss simultaneously destabilizes p53 and reduces MOF-dependent transcriptional activation of differentiation programs. The synthetic-lethal vulnerability emerges from the kinetic structure of the writer-eraser equilibrium. In PHF20-intact cells, MOF deposition and HDAC removal set the steady-state H4K16ac level. In PHF20-haploinsufficient cells, the deposition rate falls by roughly half while removal is unchanged, establishing a lower steady state that is survivable but kinetically fragile. Pharmacologic HDAC1/2 inhibition transiently abolishes the eraser arm; PHF20-intact cells, with a strong writer arm, tolerate the perturbation, whereas PHF20-deficient cells, lacking the writer capacity to buffer it, undergo catastrophic equilibrium collapse with arrest, differentiation, or death. Two predictions follow: the effect should appear at sub-maximal HDAC inhibition, and it should be strongly context-dependent on PHF20 status. The drug-screen data (Figure 21), showing del(20q)-preferential activity at intermediate concentrations, are consistent with both.")

H2("1.4.3 HDAC inhibition as differentiation therapy")
P("Beyond cytotoxic synthetic lethality, the model predicts that HDAC inhibition should act as differentiation therapy in del(20q) disease. Because PHF20 loss produces a differentiation block (expanded clonogenic progenitors that fail to mature, Sections 1.3.9\u20131.3.12), restoring H4K16 acetylation by inhibiting the opposing HDAC2 eraser should re-open differentiation-permissive chromatin and allow the arrested progenitors to complete maturation. In our immunophenotyping framework, CD34 marks the immature hematopoietic stem and progenitor compartment, while CD11b (integrin alpha-M) is acquired during myelomonocytic maturation; the ratio of the two is a standard readout of myeloid differentiation state " + C("civin1984cd34", "solovjov2005cd11b") + ". The differentiation-therapy paradigm is well precedented: all-trans retinoic acid in acute promyelocytic leukemia is the canonical example " + C("dethe2018") + ", and HDAC inhibitors specifically have been shown to drive leukemic differentiation and apoptosis " + C("nebbioso2005", "garciamanero2008vorinostat") + ". The prediction that an HDAC inhibitor will raise the CD11b:CD34 ratio in PHF20-deficient cells, reversing the block quantified in Figure 20, is directly testable and constitutes a definitive prediction of the differentiation-therapy model.")

H2("1.4.4 del(20q) in the context of other haploinsufficient deletion syndromes")
P("The PHF20 model places del(20q) alongside the other recurrent myeloid deletions whose drivers act through haploinsufficiency rather than biallelic inactivation. In del(5q), RPS14 haploinsufficiency drives the erythroid defect through p53 activation in the erythroid lineage " + C("ebert2008rps14", "pellagatti2010") + ", while CSNK1A1 haploinsufficiency contributes the clonal-advantage component and underlies lenalidomide sensitivity " + C("kronke2015", "schneider2014") + ". In del(7q), CUX1 and MLL3 act as haploinsufficient tumor suppressors " + C("mcnerney2013cux1", "wong2014cux1", "chen2014mll3") + ". del(20q) fits this paradigm, with PHF20 as the dosage-sensitive driver, but is distinguished by a directly actionable therapeutic axis: whereas del(5q) is targeted by lenalidomide largely through CSNK1A1-dependent degradation " + C("list2006len") + ", del(20q) is predicted to be targetable through the writer-eraser logic of HDAC inhibition.")

H2("1.4.5 Translational and therapeutic implications")
P("The choice of HDAC inhibitors as the therapeutic strategy was not predetermined; it emerged from convergent integration of orthogonal data. The Markov/MCMC analysis of the PANDA network ranked HDAC2 among the most central regulatory nodes (Section 1.3.6); PHF20 biology defined it as the eraser opposing the lost writer (Figures 14\u201316); functional knockdown established the chromatin-state and differentiation consequences (Figures 17\u201320); high-throughput screening of patient samples identified panobinostat, a potent HDAC1/2 inhibitor, as a top differential hit among 199 compounds (Figure 21); and OncoKB pathway analysis identified HDAC2 as the druggable target whose pathway carries the largest available arsenal among all myeloid-relevant pathways (Figure 22). Four independent lines, network centrality, functional validation, empirical screen, and pharmacopoeia-wide analysis, each nominate HDAC2 inhibition, providing redundant rationale for clinical translation. Given that HDAC1 and HDAC2 are the principal class I erasers of H4K16ac, class-I-selective agents such as entinostat would be prioritized for initial testing as offering the strongest mechanistic match with the most favorable off-target profile, with pan-HDAC agents and HDAC-inhibitor plus BCL-2-inhibitor combinations as alternatives " + C("gojo2007entinostat", "prebet2014e1905", "bewersdorf2019") + ".")

H2("1.4.6 The BCL-2 and PI3K axes as parallel vulnerabilities")
P("The independent emergence of venetoclax and ABT-737 in the screen, together with the BCL-2 pathway in the OncoKB analysis, identifies apoptotic priming as a parallel vulnerability. This is mechanistically consistent with the loss of PHF20-dependent p53 stabilization, which would shift the apoptotic threshold and increase dependence on anti-apoptotic BCL-2 family members. Given the established activity of venetoclax-based regimens in myeloid disease " + C("dinardo2020venaza") + ", the combination of an HDAC inhibitor with a BH3-mimetic is an attractive rational pairing for del(20q) MN and warrants direct preclinical evaluation.")

H2("1.4.7 Limitations")
P("Several limitations qualify these conclusions. The network analysis, although unbiased in construction, depends on the quality of the input motif, PPI, and co-expression priors, and the Markov centrality ranking is sensitive to the damping factor and to network sparsification choices; the agreement between the PANDA and Markov results reduces but does not remove this dependence. The functional studies rely on transient siRNA knockdown, which models haploinsufficiency by partial dosage reduction but does not recapitulate the precise single-copy genomic loss of del(20q); CRISPR-based heterozygous deletion and isogenic models would strengthen the causal claim. The Western blot and flow-cytometry experiments central to the chromatin-state and differentiation-block predictions (Figures 19 and 20) are in progress, and their placeholders must be replaced with experimental data before the model is considered validated at those steps. Finally, the therapeutic predictions derive from ex vivo screening and require validation in vivo and ultimately in patients with del(20q) disease.")

H2("1.4.8 Future directions")
P("Definitive causal confirmation in CRISPR-engineered isogenic PHF20-heterozygous models, in vivo evaluation of HDAC-inhibitor and HDAC-inhibitor plus BH3-mimetic regimens in del(20q) models " + C("dinardo2020venaza", "bewersdorf2019") + ", and correlative analysis of HDAC-inhibitor response by del(20q) status in clinical datasets would extend the present findings toward translation.")

H2("1.4.9 Conclusion")
P("This chapter identifies PHF20 as the haploinsufficient driver of del(20q) myeloid neoplasia and the histone deacetylase HDAC2 as its actionable therapeutic counterpart, linked through the MOF/NSL\u2013H4K16ac writer-eraser axis. The convergence of an unbiased network analysis that surfaces both arms of this axis, functional studies that reproduce the proliferative and differentiation phenotypes, and orthogonal druggability analyses that nominate the same target establishes a mechanistic and translational framework in which a previously orphaned cytogenetic lesion becomes a candidate for lesion-directed differentiation therapy.")

# ===================== 2.5 REFERENCES =====================
PB()
H1("1.5 References")
for num, text in ct.ordered_refs():
    p = doc.add_paragraph()
    p.paragraph_format.first_line_indent = Inches(-0.4)
    p.paragraph_format.left_indent = Inches(0.4)
    p.paragraph_format.line_spacing = 1.5
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(f"{num}. "); r.bold = True; r.font.size = Pt(11)
    r2 = p.add_run(text); r2.font.size = Pt(11)

# ===================== ETD FINALIZATION =====================
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

def _page_field(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    paragraph.paragraph_format.first_line_indent = Inches(0)
    paragraph.paragraph_format.line_spacing = 1.0
    run = paragraph.add_run()
    b = OxmlElement('w:fldChar'); b.set(qn('w:fldCharType'), 'begin')
    it = OxmlElement('w:instrText'); it.set(qn('xml:space'), 'preserve'); it.text = 'PAGE'
    e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'), 'end')
    for el in (b, it, e):
        run._r.append(el)
    run.font.name = 'Times New Roman'; run.font.size = Pt(11)

def _set_pgnum(section, fmt, start=None):
    sectPr = section._sectPr
    pg = sectPr.find(qn('w:pgNumType'))
    if pg is None:
        pg = OxmlElement('w:pgNumType'); sectPr.append(pg)
    pg.set(qn('w:fmt'), fmt)
    if start is not None:
        pg.set(qn('w:start'), str(start))

sec0, sec1 = doc.sections[0], doc.sections[1]
# Front matter: lowercase roman, number suppressed on the title page (first page)
sec0.different_first_page_header_footer = True
_set_pgnum(sec0, 'lowerRoman')
sec0.header.is_linked_to_previous = False
_page_field(sec0.header.paragraphs[0])
sec0.first_page_header.is_linked_to_previous = False  # left intentionally blank (title page)
# Body: arabic, restart at 1, number top-right on every page
sec1.different_first_page_header_footer = False
sec1.header.is_linked_to_previous = False
_set_pgnum(sec1, 'decimal', start=1)
_page_field(sec1.header.paragraphs[0])

# Accessibility (MDAS): document language + title/author metadata; update fields on open
rpr = doc.styles['Normal'].element.get_or_add_rPr()
lang = rpr.find(qn('w:lang'))
if lang is None:
    lang = OxmlElement('w:lang'); rpr.append(lang)
lang.set(qn('w:val'), 'en-US')
doc.core_properties.author = "Mark Orland, MD"
doc.core_properties.title = "Determining the Etiology and Targetability of del(20q) Myeloid Neoplasms"
doc.core_properties.language = "en-US"
settings = doc.settings.element
upd = settings.find(qn('w:updateFields'))
if upd is None:
    upd = OxmlElement('w:updateFields'); settings.append(upd)
upd.set(qn('w:val'), 'true')

doc.save(os.path.join(BUILD_DIR,'thesis.docx'))
print(f"FINAL saved — paragraphs: {len(doc.paragraphs)}; total references: {len(ct._order)}")
