"""
compute_toc_pages.py

Renders the assembled thesis to PDF (LibreOffice), reads the printed page number
of every Heading 1-3 and every "Figure N" caption, and writes
<repo>/build/toc_pages.json. build_part1.py reads that JSON on the second pass to
emit a STATIC Table of Contents and List of Figures with page numbers that are
correct in any viewer.

Requires: LibreOffice (soffice) and poppler (pdftotext, pdfinfo) on PATH.
"""
import os, re, json, subprocess

HERE      = os.path.dirname(os.path.abspath(__file__))
BASE      = os.path.dirname(HERE)
BUILD_DIR = os.path.join(BASE, 'build')
DOCX      = os.path.join(BUILD_DIR, 'thesis.docx')
PDF       = os.path.join(BUILD_DIR, 'thesis.pdf')
PARTS     = [os.path.join(HERE, f) for f in ('build_part1.py', 'build_part2.py', 'build_part3.py')]
N_FIGURES = 24   # update if the figure count changes


def render_pdf():
    subprocess.run(['soffice', '--headless', '--convert-to', 'pdf', '--outdir', BUILD_DIR, DOCX],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def page_text(p):
    return subprocess.run(['pdftotext', '-layout', '-f', str(p), '-l', str(p), PDF, '-'],
                          capture_output=True, text=True).stdout


def n_pages():
    out = subprocess.run(['pdfinfo', PDF], capture_output=True, text=True).stdout
    return int(re.search(r'Pages:\s+(\d+)', out).group(1))


def printed_label(text):
    for line in text.splitlines():
        s = line.strip()
        if s:
            return s.split()[-1]
    return None


def headings():
    out = []
    for f in PARTS:
        for line in open(f, encoding='utf-8'):
            m = re.match(r'\s*(H1|H2|H3)\("([^"]+)"\)', line)
            if m:
                out.append(m.group(2).encode().decode('unicode_escape'))
    return out


def main():
    render_pdf()
    n = n_pages()
    texts  = {p: page_text(p) for p in range(1, n + 1)}
    labels = {p: printed_label(texts[p]) for p in range(1, n + 1)}
    arabic = lambda p: labels[p] is not None and labels[p].isdigit()
    norm   = lambda s: re.sub(r'\s+', ' ', s).strip()
    pages = {}
    for h in headings():
        pages['HEAD::' + h] = next((labels[p] for p in range(1, n + 1)
                                    if arabic(p) and norm(h)[:40] in norm(texts[p])), '00')
    for i in range(1, N_FIGURES + 1):
        pages['FIG::%d' % i] = next((labels[p] for p in range(1, n + 1)
                                     if arabic(p) and re.search(r'Figure ' + str(i) + r'\.(?!\d)', norm(texts[p]))), '00')
    json.dump(pages, open(os.path.join(BUILD_DIR, 'toc_pages.json'), 'w'), ensure_ascii=False, indent=0)
    missing = [k for k, v in pages.items() if v == '00']
    print('computed %d page references; missing: %s' % (len(pages), missing or 'none'))


if __name__ == '__main__':
    main()
