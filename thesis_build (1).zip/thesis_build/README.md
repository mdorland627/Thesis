# del(20q) / PHF20 thesis — analysis and build pipeline

Code for the PhD thesis chapter *"Determining the Etiology and Targetability of
del(20q) Myeloid Neoplasms."* The toolchain is split by language:

- **R** (`R/`) — the network and Markov-chain analyses and all statistical-figure
  generation (volcano plots, regressions, circos, heatmaps).
- **Python** (`python/`) — the document-build pipeline that assembles the
  CWRU-ETD-formatted chapter from the generated figures.

## Which script does what

| Analysis | Script | Language |
|----------|--------|----------|
| PANDA gene-regulatory-network construction | `R/01_panda_network.R` | R (netZooR) |
| Markov / MCMC PageRank network centrality (ranks HDAC2 top, PHF20 mid-tier) | `R/02_markov_pagerank_centrality.R` | R (igraph, coda) |
| Serial-cytogenetics continuous-time Markov model + swimmer plot | `R/03_serial_cytogenetics_markov.R` | R (msm, ggplot2) |
| Clonality-corrected differential expression + volcano plots (genome-wide and CDR haploinsufficiency) + gene-dose regressions | `R/04_differential_expression_volcano.R` | R (limma, ggplot2) |
| Cytogenetic-landscape / DEG circos + 20q- signature heatmap | `R/05_genomic_figures.R` | R (circlize, ComplexHeatmap) |
| Citation manager (appearance-order numbering, auto bibliography) | `python/citemod.py` | Python |
| Front matter, Introduction, Methods | `python/build_part1.py` | Python |
| Results (figure placement + captions) | `python/build_part2.py` | Python |
| Discussion, References, finalize | `python/build_part3.py` | Python |
| Page-number computation for static TOC / List of Figures | `python/compute_toc_pages.py` | Python |
| One-command two-pass build orchestrator | `python/build.py` | Python |

The R scripts write figure images into `figures/`; the Python build reads them
from there. Generated `.docx`/`.pdf` and intermediate state land in `build/`.

## Run the analyses (R)

```r
source("install_R_packages.R")   # netZooR, igraph, coda, msm, limma, circlize, ComplexHeatmap, ggplot2 ...
# then, with input files in data/ (see data/README.md):
Rscript R/01_panda_network.R
Rscript R/02_markov_pagerank_centrality.R
Rscript R/03_serial_cytogenetics_markov.R
Rscript R/04_differential_expression_volcano.R
Rscript R/05_genomic_figures.R
```

Scripts 01 → 02 are sequential (02 reads the network 01 produces). The others are
independent. Each writes to `figures/` and/or `build/`.

## Build the chapter (Python)

```bash
pip install -r requirements.txt
# also needs LibreOffice (soffice) and poppler (pdftotext, pdfinfo) on PATH
python python/build.py        # -> build/thesis.docx and build/thesis.pdf
```

### Two-pass build
A Word TOC *field* shows "1" everywhere until Word rebuilds it. Instead the
pipeline emits a **static** TOC and List of Figures with real page numbers:
pass 1 builds with placeholder numbers, `compute_toc_pages.py` renders to PDF and
reads the printed page of every heading and `Figure N` caption, then pass 2
rebuilds with the real numbers. Because line counts don't change between passes,
pagination is stable across Word, Google Docs, and PDF.

### Figures
`figures/` holds `figXX_*.png/.jpg` named exactly as referenced in
`build_part2.py`. Any missing figure renders as a captioned placeholder, so the
document always builds. The R scripts regenerate these from source data; you can
also drop in finished panels directly.

## Notes
- Methods correspondence: the network Markov step uses a damped random walk
  (d = 0.85) estimated by MCMC with Gelman-Rubin convergence, matching the thesis
  Methods; `msm` is used for the interval-censored serial-cytogenetics CTMC.
- The R figure scripts are reference implementations keyed to the file layout in
  `data/README.md`; adapt the input paths to your data.
- Requires Python 3.9+ and R 4.x.
