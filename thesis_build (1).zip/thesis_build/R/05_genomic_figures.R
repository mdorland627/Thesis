# =============================================================================
# 05_genomic_figures.R
# Genomic figure generation in R: the cytogenetic-landscape and DEG-distribution
# circos plots, and the 20q- signature heatmap. (The "other versions" of figures.)
#
# Inputs (../data/):
#   cn_events.tsv     columns: chrom, start, end, type(loss/gain/upd)   (recurrent CN events)
#   de_results.tsv    from 04 (gene, log2FC, fdr) with chrom/pos joined
#   gene_positions.tsv columns: gene, chrom, pos
#   signature_matrix.tsv  genes x samples z-scored expression (top-100 signature)
#   sample_groups.tsv   columns: sample, group(del20q/diploid)
# Outputs (../figures/):
#   fig01_cytogenetic_landscape.png, fig10_deg_circos.png, fig08_signature_heatmap.png
#
# Requires: circlize, ComplexHeatmap, data.table.
# =============================================================================

suppressMessages({ library(circlize); library(ComplexHeatmap); library(data.table) })

here <- tryCatch(dirname(normalizePath(sub("--file=", "",
        grep("--file=", commandArgs(FALSE), value = TRUE)[1]))), error = function(e) getwd())
repo <- normalizePath(file.path(here, ".."))
fig  <- file.path(repo, "figures"); dd <- file.path(repo, "data"); bld <- file.path(repo, "build")
dir.create(fig, showWarnings = FALSE, recursive = TRUE)

# ---- (1) Cytogenetic-landscape circos: loss / gain / UPD tracks -------------
cn <- fread(file.path(dd, "cn_events.tsv"))
png(file.path(fig, "fig01_cytogenetic_landscape.png"), width = 1600, height = 1600, res = 200)
circos.clear(); circos.par(start.degree = 90, gap.degree = 2)
circos.initializeWithIdeogram(species = "hg38")
for (tp in c("loss", "gain", "upd")) {
  sub <- cn[type == tp]
  col <- c(loss = "#2c6fbb", gain = "#c0392b", upd = "#e6a000")[tp]
  circos.genomicTrackPlotRegion(
    as.data.frame(sub[, .(chrom, start, end, value = 1)]),
    ylim = c(0, 1), track.height = 0.12,
    panel.fun = function(region, value, ...) circos.genomicRect(region, value, col = col, border = NA))
}
title("Recurrent CN events — all patients")
dev.off()

# ---- (2) Genome-wide DEG-distribution circos -------------------------------
if (file.exists(file.path(bld, "de_results.tsv")) && file.exists(file.path(dd, "gene_positions.tsv"))) {
  de  <- fread(file.path(bld, "de_results.tsv"))
  pos <- fread(file.path(dd, "gene_positions.tsv"))
  m   <- merge(de, pos, by = "gene")
  m[, dir := ifelse(log2FC > 0, "up", "down")]
  png(file.path(fig, "fig10_deg_circos.png"), width = 1600, height = 1600, res = 200)
  circos.clear(); circos.par(start.degree = 90); circos.initializeWithIdeogram(species = "hg38")
  circos.genomicTrackPlotRegion(
    as.data.frame(m[fdr < 0.05, .(chrom, start = pos, end = pos, log2FC,
                                  col = ifelse(dir == "up", "#c0392b", "#2c6fbb"))]),
    panel.fun = function(region, value, ...) circos.genomicPoints(region, value, pch = 16, cex = 0.3,
                                                                  col = value$col))
  title("Genome-wide differentially expressed genes")
  dev.off()
}

# ---- (3) 20q- signature heatmap --------------------------------------------
if (file.exists(file.path(dd, "signature_matrix.tsv"))) {
  mat <- as.data.frame(fread(file.path(dd, "signature_matrix.tsv"))); rownames(mat) <- mat[[1]]; mat[[1]] <- NULL
  grp <- fread(file.path(dd, "sample_groups.tsv"))
  ha  <- HeatmapAnnotation(Group = grp$group[match(colnames(mat), grp$sample)],
                           col = list(Group = c(del20q = "#c0392b", diploid = "#2c6fbb")))
  png(file.path(fig, "fig08_signature_heatmap.png"), width = 1600, height = 1100, res = 200)
  draw(Heatmap(as.matrix(mat), name = "z", top_annotation = ha,
               show_row_names = FALSE, show_column_names = FALSE,
               col = colorRamp2(c(-4, 0, 4), c("#2166ac", "white", "#b2182b"))))
  dev.off()
}
cat("Saved genomic figures to ../figures/\n")
