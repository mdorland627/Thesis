# =============================================================================
# 01_panda_network.R
# PANDA gene regulatory network construction for the del(20q) CDR genes.
#
# PANDA (Passing Attributes between Networks for Data Assimilation) integrates a
# TF-target motif prior, a protein-protein interaction (PPI) prior, and a gene
# co-expression matrix into a single message-passing network in which an edge is
# reinforced only where the independent evidence types agree.
#
# Inputs (place in ../data/):
#   motif_prior.txt   3 cols: TF, target_gene, weight(0/1)        (regulatory prior)
#   ppi_prior.txt     3 cols: protein1, protein2, weight          (cooperativity prior)
#   expression.txt    genes x samples expression matrix (RNA-seq, log/normalized)
#
# Output (../build/):
#   panda_network.rds     full regularized regulatory network (TF x gene weights)
#   panda_edges.tsv       long edge list (TF, gene, weight)
#   panda_top_regulators.tsv
#
# Reproduces the network used by 02_markov_pagerank_centrality.R.
# Requires: netZooR (PANDA implementation), reshape2, data.table.
# =============================================================================

suppressMessages({
  library(netZooR)     # provides panda()
  library(data.table)
  library(reshape2)
})

here     <- dirname(normalizePath(sub("--file=", "", grep("--file=", commandArgs(FALSE), value = TRUE)[1])))
if (length(here) == 0 || is.na(here)) here <- getwd()
repo     <- normalizePath(file.path(here, ".."))
data_dir <- file.path(repo, "data")
out_dir  <- file.path(repo, "build"); dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

motif <- fread(file.path(data_dir, "motif_prior.txt"), header = FALSE,
               col.names = c("tf", "gene", "weight"))
ppi   <- fread(file.path(data_dir, "ppi_prior.txt"), header = FALSE,
               col.names = c("p1", "p2", "weight"))
expr  <- as.data.frame(fread(file.path(data_dir, "expression.txt")), stringsAsFactors = FALSE)
rownames(expr) <- expr[[1]]; expr[[1]] <- NULL

message("Running PANDA: ", nrow(expr), " genes x ", ncol(expr), " samples")

# PANDA message passing to convergence (default hamming threshold 0.001).
panda_res <- panda(
  motif      = as.data.frame(motif),
  expr       = expr,
  ppi        = as.data.frame(ppi),
  hamming    = 0.001,
  progress   = TRUE
)

reg_net <- panda_res@regNet          # TF (rows) x gene (cols) weighted matrix
saveRDS(panda_res, file.path(out_dir, "panda_network.rds"))

edges <- melt(as.matrix(reg_net), varnames = c("tf", "gene"), value.name = "weight")
edges <- edges[order(-edges$weight), ]
fwrite(edges, file.path(out_dir, "panda_edges.tsv"), sep = "\t")

# Candidate master regulators: mean out-edge weight per TF.
top_reg <- aggregate(weight ~ tf, data = edges, FUN = mean)
top_reg <- top_reg[order(-top_reg$weight), ]
fwrite(top_reg, file.path(out_dir, "panda_top_regulators.tsv"), sep = "\t")

message("Saved panda_network.rds, panda_edges.tsv, panda_top_regulators.tsv")
message("Top regulators: ", paste(head(top_reg$tf, 10), collapse = ", "))
