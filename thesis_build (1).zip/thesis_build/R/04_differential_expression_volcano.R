# =============================================================================
# 04_differential_expression_volcano.R
# Clonality-corrected differential expression and the volcano plots, plus the
# gene-dose (copy-number) regressions. All figure versions are produced here in R.
#
# Two volcanoes are generated:
#   (1) genome-wide DE: del(20q) vs copy-number-diploid controls (Figure 10 source)
#   (2) CDR-restricted haploinsufficiency screen: retained 20q genes only (Figure 6)
# plus the gene-dose regressions of expression on del(20q) clonal fraction (Figure 7).
#
# Clonality correction: each gene's expression is modeled as a function of the
# patient-specific del(20q) clonal fraction; the dosage effect is the slope, and
# significance is taken at the pure-clone extrapolation. limma is used with the
# clonal fraction as a continuous covariate.
#
# Inputs (../data/):
#   expression.txt   genes x samples (log2 normalized)
#   sample_meta.tsv  columns: sample, group(del20q/diploid), clonal_fraction(0-1)
#   cdr_genes.txt    one gene symbol per line (126 CDR genes)
# Outputs (../figures/): fig06_volcano_haploinsufficiency.png,
#   fig10_volcano_genomewide.png, fig07_gene_dose_regressions.png
#   (../build/): de_results.tsv
#
# Requires: limma, ggplot2, ggrepel, data.table.
# =============================================================================

suppressMessages({ library(limma); library(ggplot2); library(ggrepel); library(data.table) })

here <- tryCatch(dirname(normalizePath(sub("--file=", "",
        grep("--file=", commandArgs(FALSE), value = TRUE)[1]))), error = function(e) getwd())
repo <- normalizePath(file.path(here, ".."))
fig  <- file.path(repo, "figures"); bld <- file.path(repo, "build"); dd <- file.path(repo, "data")
dir.create(fig, showWarnings = FALSE, recursive = TRUE); dir.create(bld, showWarnings = FALSE, recursive = TRUE)

expr <- as.data.frame(fread(file.path(dd, "expression.txt"))); rownames(expr) <- expr[[1]]; expr[[1]] <- NULL
meta <- fread(file.path(dd, "sample_meta.tsv"))
cdr  <- readLines(file.path(dd, "cdr_genes.txt"))
expr <- expr[, meta$sample, drop = FALSE]

# ---- DE: del(20q) vs diploid, FDR via limma --------------------------------
grp    <- factor(meta$group, levels = c("diploid", "del20q"))
design <- model.matrix(~ grp)
fit    <- eBayes(lmFit(as.matrix(expr), design))
tt     <- topTable(fit, coef = 2, number = Inf, sort.by = "none")
de <- data.frame(gene = rownames(tt), log2FC = tt$logFC, p = tt$P.Value, fdr = tt$adj.P.Val)
fwrite(de, file.path(bld, "de_results.tsv"), sep = "\t")

volcano <- function(df, title, outfile, label_top = 15) {
  df$sig <- ifelse(df$fdr < 0.05 & abs(df$log2FC) > 0.5, "sig", "ns")
  lab <- df[df$sig == "sig", ]; lab <- lab[order(lab$p), ][seq_len(min(label_top, nrow(lab))), ]
  p <- ggplot(df, aes(log2FC, -log10(p))) +
    geom_point(aes(colour = sig), size = 1.1, alpha = 0.7) +
    scale_colour_manual(values = c(ns = "grey70", sig = "#c0392b"), guide = "none") +
    geom_vline(xintercept = c(-0.5, 0.5), linetype = "dashed", colour = "grey60") +
    geom_hline(yintercept = -log10(0.05), linetype = "dashed", colour = "grey60") +
    geom_text_repel(data = lab, aes(label = gene), size = 2.6, max.overlaps = 20) +
    labs(x = expression(Log[2]~fold~change), y = expression(-Log[10]~italic(P)), title = title) +
    theme_bw(base_size = 11)
  ggsave(outfile, p, width = 6.5, height = 5, dpi = 200)
}

# (1) genome-wide volcano
volcano(de, "Genome-wide differential expression: del(20q) vs diploid",
        file.path(fig, "fig10_volcano_genomewide.png"))
# (2) CDR-restricted haploinsufficiency volcano
de_cdr <- de[de$gene %in% cdr, ]
volcano(de_cdr, "Haploinsufficiency of retained CDR genes (del(20q) vs diploid)",
        file.path(fig, "fig06_volcano_haploinsufficiency.png"))

# ---- Gene-dose regressions: expression vs del(20q) clonal fraction ---------
# Top dosage-dependent genes by R^2 of expression ~ clonal_fraction within del(20q).
del <- meta[meta$group == "del20q", ]
cf  <- setNames(del$clonal_fraction, del$sample)
r2  <- sapply(cdr[cdr %in% rownames(expr)], function(g) {
  y <- as.numeric(expr[g, del$sample]); summary(lm(y ~ cf[del$sample]))$r.squared
})
top_genes <- names(sort(r2, decreasing = TRUE))[seq_len(min(6, sum(!is.na(r2))))]

reg_df <- do.call(rbind, lapply(top_genes, function(g)
  data.frame(gene = g, cn_loss = 100 * cf[del$sample],
             expr = as.numeric(expr[g, del$sample]))))
p <- ggplot(reg_df, aes(cn_loss, expr)) +
  geom_point(size = 1.3) +
  geom_smooth(method = "lm", se = FALSE, colour = "#c0392b", linewidth = 0.7) +
  facet_wrap(~ gene, scales = "free_y") +
  labs(x = "Copy-number loss (%)", y = expression(Expression~(log[2]~FC))) +
  theme_bw(base_size = 10)
ggsave(file.path(fig, "fig07_gene_dose_regressions.png"), p, width = 7, height = 6, dpi = 200)

cat("Saved fig06_volcano_haploinsufficiency.png, fig10_volcano_genomewide.png,",
    "fig07_gene_dose_regressions.png, de_results.tsv\n")
