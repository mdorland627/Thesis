# =============================================================================
# 03_serial_cytogenetics_markov.R
# Continuous-time Markov model of clonal evolution in serial del(20q) cytogenetics,
# and the swimmer plot.
#
# Ordinal clonal-burden states:
#   1  Isolated del(20q)          (sole clonal aberration)
#   2  del(20q) + 1-2 additional  (non-complex)
#   3  Complex karyotype          (>= 3 aberrations)
#
# A continuous-time Markov chain is fit by maximum likelihood to interval-censored
# panel data (the msm package), which accommodates unequal sampling intervals and
# transitions occurring between observed samples. Outputs the generator, 1-year
# transition probabilities, mean sojourn (dwell) times, and bootstrap CIs.
#
# Input (../data/serial_cytogenetics.tsv): columns
#   patient   time_years   state(1/2/3)     (long format, one row per timepoint)
# Output (../figures/): fig24_swimmer.png ; (../build/): markov_ctmc_summary.txt
#
# Requires: msm, ggplot2, data.table.
# =============================================================================

suppressMessages({ library(msm); library(ggplot2); library(data.table) })

here <- tryCatch(dirname(normalizePath(sub("--file=", "",
        grep("--file=", commandArgs(FALSE), value = TRUE)[1]))), error = function(e) getwd())
repo <- normalizePath(file.path(here, ".."))
fig  <- file.path(repo, "figures"); bld <- file.path(repo, "build")
dir.create(fig, showWarnings = FALSE, recursive = TRUE); dir.create(bld, showWarnings = FALSE, recursive = TRUE)

dat <- fread(file.path(repo, "data", "serial_cytogenetics.tsv"))
setorder(dat, patient, time_years)
dat <- unique(dat, by = c("patient", "time_years"))

cat("patients =", uniqueN(dat$patient), " timepoints =", nrow(dat), "\n")
print(statetable.msm(state, patient, data = dat))

# All states inter-communicate except where biologically constrained; allow all
# 1<->2<->3 transitions (3 is near-absorbing empirically, not forced).
Q0 <- rbind(c(0, 0.2, 0.05),
            c(0.2, 0, 0.2),
            c(0.05, 0.05, 0))
Q0 <- crudeinits.msm(state ~ time_years, patient, data = dat, qmatrix = Q0)

fit <- msm(state ~ time_years, subject = patient, data = dat, qmatrix = Q0,
           gen.inits = FALSE, control = list(fnscale = 4000, maxit = 10000))

sink(file.path(bld, "markov_ctmc_summary.txt"))
cat("=== Generator matrix Q (per year) ===\n");           print(round(qmatrix.msm(fit)$estimate, 3))
cat("\n=== 1-year transition probabilities P(1) ===\n");   print(round(pmatrix.msm(fit, t = 1), 3))
cat("\n=== Mean sojourn (dwell) times, years ===\n");      print(round(sojourn.msm(fit)$estimates, 2))
sink()
cat(readLines(file.path(bld, "markov_ctmc_summary.txt")), sep = "\n")

# ---- Swimmer plot ----------------------------------------------------------
lab <- c("Isolated del(20q)", "del(20q) + additional", "Complex karyotype")
pal <- c("#1b9e77", "#e6a000", "#c0392b")
ord <- dat[, .(last = state[.N]), by = patient][order(last)]$patient
dat[, patient := factor(patient, levels = ord)]
dat[, months := time_years * 12]

p <- ggplot(dat, aes(months, patient)) +
  geom_line(aes(group = patient), colour = "grey75", linewidth = 0.4) +
  geom_point(aes(colour = factor(state)), size = 2.4) +
  scale_colour_manual(values = pal, labels = lab, name = NULL) +
  labs(x = "Months from first cytogenetic sample", y = NULL,
       title = sprintf("Clonal-state trajectories across %d del(20q) patients", uniqueN(dat$patient))) +
  theme_minimal(base_size = 11) +
  theme(legend.position = "bottom", panel.grid.major.y = element_blank())
ggsave(file.path(fig, "fig24_swimmer.png"), p, width = 11, height = 7, dpi = 200)
cat("Saved fig24_swimmer.png and markov_ctmc_summary.txt\n")

# ---- Optional: patient-level bootstrap CIs on P(1) (uncomment to run) -------
# boot <- boot.msm(fit, stat = function(x) pmatrix.msm(x, t = 1), B = 1000)
