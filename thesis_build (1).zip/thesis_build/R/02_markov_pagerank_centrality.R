# =============================================================================
# 02_markov_pagerank_centrality.R
# Markov-chain (random-walk / PageRank) centrality on the converged PANDA network.
#
# The weighted regulatory network is treated as a Markov chain: a damped random
# walk is run over it and the stationary distribution (the fraction of time the
# walker spends at each node) ranks genes by how much regulatory flow concentrates
# through them. This is the analysis that ranks HDAC2 at the top of the chromatin-
# modifying nodes and places PHF20 mid-tier (consistent with an epigenetic, complex-
# based regulator rather than a transcription-factor hub).
#
# Two estimators are computed and cross-checked:
#   (a) MCMC random-walk simulation with multiple chains, convergence assessed by
#       the Gelman-Rubin statistic (matches the thesis Methods).
#   (b) igraph::page_rank (deterministic power-iteration) as a validation.
# Degree and betweenness are also computed; a composite importance score is the
# geometric mean of percentile-rank-normalized centralities.
#
# Input  (../build/):  panda_network.rds  (from 01_panda_network.R)
# Output (../build/):  centrality_ranking.tsv
#         (../figures/): fig_centrality_radar.png (optional supporting plot)
#
# Requires: igraph, coda (Gelman-Rubin), ggplot2.
# =============================================================================

suppressMessages({ library(igraph); library(coda); library(ggplot2) })

here  <- tryCatch(dirname(normalizePath(sub("--file=", "",
          grep("--file=", commandArgs(FALSE), value = TRUE)[1]))), error = function(e) getwd())
repo  <- normalizePath(file.path(here, ".."))
bld   <- file.path(repo, "build"); fig <- file.path(repo, "figures")
dir.create(fig, showWarnings = FALSE, recursive = TRUE)

panda <- readRDS(file.path(bld, "panda_network.rds"))
W <- as.matrix(panda@regNet)              # TF x gene weights
# Build a single square node set (union of TFs and genes) weighted adjacency.
nodes <- union(rownames(W), colnames(W))
A <- matrix(0, length(nodes), length(nodes), dimnames = list(nodes, nodes))
A[rownames(W), colnames(W)] <- pmax(W, 0)  # keep non-negative edge weights
N <- nrow(A)

# --- Row-stochastic transition matrix M (dangling rows -> uniform) ---
rs <- rowSums(A); rs[rs == 0] <- 1
M  <- A / rs
dangling <- rowSums(A) == 0
M[dangling, ] <- 1 / N
d <- 0.85                                   # damping factor

# --- (a) MCMC random-walk PageRank, multiple chains + Gelman-Rubin ----------
mcmc_pagerank <- function(M, d, iters = 1000, chains = 4, seed = 1) {
  N <- nrow(M); idx <- seq_len(N)
  chain_list <- vector("list", chains)
  for (cc in seq_len(chains)) {
    set.seed(seed + cc)
    visits <- numeric(N); pos <- sample(idx, 1)
    trace  <- matrix(0, iters, N)
    for (t in seq_len(iters)) {
      if (runif(1) < d) {
        p <- M[pos, ]
        pos <- if (sum(p) > 0) sample(idx, 1, prob = p) else sample(idx, 1)
      } else pos <- sample(idx, 1)          # teleport
      visits[pos] <- visits[pos] + 1
      trace[t, ]  <- visits / t             # running stationary estimate
    }
    chain_list[[cc]] <- mcmc(trace[, seq_len(min(N, 50))])  # monitor subset for R-hat
  }
  # Gelman-Rubin on a monitored subset of nodes
  rhat <- tryCatch(gelman.diag(mcmc.list(chain_list), autoburnin = TRUE,
                               multivariate = FALSE)$psrf[, 1], error = function(e) NA)
  # final stationary estimate = average of last-row visit frequencies across chains
  pi_hat <- Reduce(`+`, lapply(chain_list, function(m) as.numeric(m[nrow(m), ]))) / chains
  list(pi = setNames(pi_hat, colnames(M)[seq_along(pi_hat)]), rhat = rhat)
}
mc <- mcmc_pagerank(M, d, iters = 1000, chains = 4)
message("Max Gelman-Rubin R-hat (monitored nodes): ",
        round(suppressWarnings(max(mc$rhat, na.rm = TRUE)), 3))

# --- (b) Deterministic PageRank for validation ------------------------------
g  <- graph_from_adjacency_matrix(A, mode = "directed", weighted = TRUE)
pr <- page_rank(g, damping = d, weights = E(g)$weight)$vector

# --- Other centralities + composite -----------------------------------------
deg  <- strength(g, mode = "all", weights = E(g)$weight)
btw  <- betweenness(g, weights = 1 / (E(g)$weight + 1e-9), directed = TRUE)
pr01 <- rank(pr) / length(pr); dg01 <- rank(deg) / length(deg); bt01 <- rank(btw) / length(btw)
composite <- exp((log(pr01) + log(dg01) + log(bt01)) / 3)   # geometric mean of percentile ranks

res <- data.frame(gene = names(pr), pagerank = as.numeric(pr),
                  degree = deg[names(pr)], betweenness = btw[names(pr)],
                  composite = composite[names(pr)], row.names = NULL)
res <- res[order(-res$pagerank), ]
res$pagerank_rank <- seq_len(nrow(res))
write.table(res, file.path(bld, "centrality_ranking.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

show_rank <- function(gn) if (gn %in% res$gene)
  message(sprintf("  %s: PageRank rank %d / %d", gn, res$pagerank_rank[res$gene == gn], nrow(res)))
message("PageRank-ranked nodes (top 8): ", paste(head(res$gene, 8), collapse = ", "))
show_rank("HDAC2"); show_rank("PHF20")
message("Saved centrality_ranking.tsv")
