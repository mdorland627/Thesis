# Install R dependencies for the analysis scripts in R/.
# PANDA lives in netZooR (Bioconductor); the rest are CRAN/Bioconductor.
if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
cran <- c("igraph", "coda", "ggplot2", "ggrepel", "data.table", "reshape2", "msm", "circlize")
bioc <- c("netZooR", "limma", "ComplexHeatmap")
for (p in cran) if (!requireNamespace(p, quietly = TRUE)) install.packages(p)
for (p in bioc) if (!requireNamespace(p, quietly = TRUE)) BiocManager::install(p, update = FALSE, ask = FALSE)
cat("R dependencies installed.\n")
